﻿"use client";

import { useState } from "react";
import * as XLSX from "xlsx";
import Link from "next/link";
import { ArrowRight, Upload, AlertCircle, CheckCircle2 } from "lucide-react";
import { useRouter } from "next/navigation";

export default function ProductImportPage() {
  const router = useRouter();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const expectedHeaders = [
    "كود المنتج", "اسم المنتج", "اسم الشركة", "القسم", "التصنيف", "عدد في الكرتونة", "سعر الكرتونة"
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (!uploadedFile) return;
    setFile(uploadedFile);
    setResult(null);

    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: "binary" });
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];
      const data = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[];
      
      const parsedData = data.slice(1).map((row) => ({
        code: row[0]?.toString() || "",
        name: row[1]?.toString() || "",
        companyName: row[2]?.toString() || "",
        categoryName: row[3]?.toString() || "",
        classificationName: row[4]?.toString() || "",
        piecesPerCarton: parseInt(row[5]) || 1,
        cartonPrice: parseFloat(row[6]) || 0
      })).filter(r => r.name && r.cartonPrice > 0);
      
      setPreview(parsedData);
    };
    reader.readAsBinaryString(uploadedFile);
  };

  const handleImport = async () => {
    if (preview.length === 0) return;
    setLoading(true);
    
    try {
      const res = await fetch("/api/admin/import/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items: preview })
      });
      
      const data = await res.json();
      setResult(data);
    } catch (error) {
      alert("حدث خطأ أثناء الاتصال بالخادم");
    } finally {
      setLoading(false);
    }
  };

  const generateTemplate = () => {
    const ws = XLSX.utils.aoa_to_sheet([expectedHeaders, ["CODE-123", "علب بلاستيك 12oz", "كرنو", "علب بلاستيك", "دائري", 500, 150.5]]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Products");
    XLSX.writeFile(wb, "products_import_template.xlsx");
  };

  return (
    <div>
      <div className="flex items-center mb-6">
        <Link href="/admin/products" className="p-2 -ml-2 text-gray-600 hover:text-gray-900 bg-gray-50 rounded-full ml-4">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold">استيراد المنتجات (Excel)</h1>
      </div>
      
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
        <div className="flex flex-col md:flex-row justify-between gap-6">
          <div className="flex-1">
            <h2 className="font-bold text-lg mb-2">تعليمات الاستيراد</h2>
            <p className="text-sm text-gray-600 mb-4 leading-relaxed">
              قم برفع ملف Excel يحتوي على الأعمدة التالية بالترتيب: 
              <br/>(كود المنتج، اسم المنتج، اسم الشركة، القسم، التصنيف، عدد القطع، سعر الكرتونة).
              <br/><br/>
              - النظام سيقوم بإضافة <b>الشركات والأقسام الجديدة</b> تلقائياً إذا لم تكن موجودة.
              <br/>
              - سيتم <b>حساب سعر القطعة</b> تلقائياً (سعر الكرتونة ÷ عدد القطع).
            </p>
            <button 
              onClick={generateTemplate}
              className="text-primary text-sm font-bold hover:underline"
            >
              تحميل ملف Excel كنموذج فارغ
            </button>
          </div>
          
          <div className="flex-1 bg-gray-50 p-6 rounded-lg border border-dashed border-gray-300 flex flex-col items-center justify-center text-center">
            <Upload className="w-10 h-10 text-gray-400 mb-3" />
            <label className="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50 cursor-pointer mb-2">
              اختر ملف Excel
              <input 
                type="file" accept=".xlsx, .xls"
                className="hidden"
                onChange={handleFileUpload}
              />
            </label>
            <span className="text-xs text-gray-500">{file ? file.name : 'لم يتم اختيار ملف'}</span>
          </div>
        </div>
      </div>

      {result && (
        <div className={`p-4 rounded-lg mb-6 flex items-start gap-3 ${result.successCount > 0 ? 'bg-green-50 border border-green-200 text-green-800' : 'bg-red-50 border border-red-200 text-red-800'}`}>
          {result.successCount > 0 ? <CheckCircle2 className="w-6 h-6 shrink-0 mt-0.5" /> : <AlertCircle className="w-6 h-6 shrink-0 mt-0.5" />}
          <div>
            <h3 className="font-bold">{result.message}</h3>
            {result.errors?.length > 0 && (
              <ul className="mt-2 text-sm list-disc list-inside">
                {result.errors.map((e: string, i: number) => <li key={i}>{e}</li>)}
              </ul>
            )}
            <button onClick={() => router.push("/admin/products")} className="mt-3 underline text-sm font-bold">
              العودة لقائمة المنتجات
            </button>
          </div>
        </div>
      )}

      {preview.length > 0 && !result && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="p-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
            <h2 className="font-semibold text-gray-700">معاينة البيانات المكتشفة ({preview.length} منتج)</h2>
            <button 
              onClick={handleImport}
              disabled={loading}
              className="bg-primary text-white px-6 py-2 rounded-md hover:bg-opacity-90 disabled:opacity-50 font-bold"
            >
              {loading ? "جاري الاستيراد..." : "تأكيد واستيراد"}
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 text-right whitespace-nowrap">
              <thead className="bg-white">
                <tr>
                  <th className="px-4 py-3 text-xs font-medium text-gray-500">الكود</th>
                  <th className="px-4 py-3 text-xs font-medium text-gray-500">اسم المنتج</th>
                  <th className="px-4 py-3 text-xs font-medium text-gray-500">الشركة</th>
                  <th className="px-4 py-3 text-xs font-medium text-gray-500">القسم / التصنيف</th>
                  <th className="px-4 py-3 text-xs font-medium text-gray-500">السعر / الكمية</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {preview.slice(0, 10).map((item, idx) => (
                  <tr key={idx} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm text-gray-900">{item.code || '-'}</td>
                    <td className="px-4 py-3 text-sm font-medium text-primary">{item.name}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{item.companyName}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{item.categoryName} <span className="text-gray-400">/ {item.classificationName}</span></td>
                    <td className="px-4 py-3 text-sm text-gray-900 font-bold">
                      {item.cartonPrice} ج.م <span className="font-normal text-xs text-gray-500">({item.piecesPerCarton} قطعة)</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {preview.length > 10 && (
              <div className="px-4 py-3 text-center text-sm text-gray-500 bg-gray-50 border-t border-gray-100">
                ... و {preview.length - 10} منتج آخر
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
