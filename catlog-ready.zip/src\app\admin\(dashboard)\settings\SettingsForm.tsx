"use client";

import { useState } from "react";
import { updateSettings } from "./actions";
import { Save, CheckCircle2 } from "lucide-react";

export function SettingsForm({ settings }: { settings: Record<string, string> }) {
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);

  async function clientAction(formData: FormData) {
    setLoading(true);
    setSaved(false);
    await updateSettings(formData);
    setLoading(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  return (
    <form action={clientAction} className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 max-w-2xl">
      <div className="space-y-6">
        
        <div>
          <label className="block text-sm font-bold text-gray-700 mb-2">اسم المتجر / الشركة</label>
          <input 
            name="companyName"
            type="text" 
            defaultValue={settings.DEFAULT_COMPANY_NAME}
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:border-transparent"
          />
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-700 mb-2">رقم الواتساب لاستقبال الطلبات</label>
          <p className="text-xs text-gray-500 mb-2">يجب أن يبدأ بمفتاح الدولة بدون أصفار أو علامة + (مثال: 966500000000 أو 201000000000)</p>
          <input 
            name="whatsappNumber"
            type="text" 
            dir="ltr"
            defaultValue={settings.DEFAULT_WHATSAPP_NUMBER}
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:border-transparent text-left font-mono"
          />
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-700 mb-2">العملة الافتراضية للمتجر</label>
          <input 
            name="currency"
            type="text" 
            defaultValue={settings.DEFAULT_CURRENCY}
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-primary focus:border-transparent"
          />
        </div>

      </div>

      <div className="mt-8 flex items-center justify-end gap-4 border-t pt-6">
        {saved && (
          <span className="text-green-600 font-bold flex items-center gap-1 text-sm">
            <CheckCircle2 className="w-4 h-4" /> تم الحفظ بنجاح
          </span>
        )}
        <button 
          type="submit" 
          disabled={loading}
          className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-opacity-90 disabled:opacity-50 flex items-center gap-2 font-bold"
        >
          {loading ? "جاري الحفظ..." : "حفظ الإعدادات"}
          {!loading && <Save className="w-4 h-4" />}
        </button>
      </div>
    </form>
  );
}
