import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { InlineImageUpload } from "@/components/admin/InlineImageUpload";

export default async function ProductsPage() {
  const products = await prisma.product.findMany({
    orderBy: { createdAt: 'desc' },
    include: {
      company: true,
      globalCategory: true,
    },
    take: 50,
  });

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">المنتجات</h1>
        <div className="flex gap-2">
          <Link 
            href="/admin/import/products" 
            className="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50"
          >
            استيراد Excel
          </Link>
          <Link 
            href="/admin/products/new" 
            className="bg-primary text-white px-4 py-2 rounded-md hover:bg-opacity-90"
          >
            إضافة منتج
          </Link>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200 text-right">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">المنتج</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">الكود / داخلي</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">الشركة</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">سعر كرتونة / قطعة</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {products.map((product) => (
              <tr key={product.id}>
                <td className="px-6 py-4">
                  <div className="flex items-center">
                    <InlineImageUpload 
                      currentUrl={product.imageUrl} 
                      entityType="products" 
                      entityId={product.id} 
                    />
                    <div className="mr-4">
                      <div className="text-sm font-medium text-gray-900">{product.name}</div>
                      {product.isFeatured && <span className="inline-flex text-[10px] bg-yellow-100 text-yellow-800 px-1 rounded mt-1">مميز</span>}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <div className="font-medium">{product.code || '-'}</div>
                  <div className="text-xs text-gray-400">{product.internalCode}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {product.company?.name || '-'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <div>{product.cartonPrice} ج.م</div>
                  <div className="text-xs text-gray-400">{product.piecePrice} ج.م / قطعة</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <Link href={`/admin/products/${product.id}/edit`} className="text-blue-600 hover:text-blue-900 mr-3">تعديل</Link>
                </td>
              </tr>
            ))}
            {products.length === 0 && (
              <tr>
                <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                  لا توجد منتجات حتى الآن
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
