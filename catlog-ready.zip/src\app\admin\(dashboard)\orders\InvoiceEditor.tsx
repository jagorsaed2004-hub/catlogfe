"use client";

import { useState } from "react";
import { saveInvoice } from "./invoice-actions";
import { Plus, Trash2, Save, MessageCircle } from "lucide-react";

export function InvoiceEditor({ order, allProducts, storePhone }: { order: any, allProducts: any[], storePhone: string }) {
  const [items, setItems] = useState<any[]>(order.items);
  const [invoiceDiscount, setInvoiceDiscount] = useState<number>(order.discount || 0);
  const [saving, setSaving] = useState(false);

  const [selectedProductId, setSelectedProductId] = useState("");
  const [newQuantity, setNewQuantity] = useState(1);
  const [productSearch, setProductSearch] = useState("");
  const [showProductDropdown, setShowProductDropdown] = useState(false);

  const filteredProducts = allProducts.filter(p => 
    p.name.includes(productSearch) || 
    (p.code && p.code.includes(productSearch)) || 
    (p.company?.name && p.company.name.includes(productSearch))
  ).slice(0, 10);

  const handleAddItem = () => {
    if (!selectedProductId) return;
    const prod = allProducts.find(p => p.id === parseInt(selectedProductId));
    if (!prod) return;

    setItems([...items, {
      productId: prod.id,
      productNameSnapshot: prod.name,
      productCodeSnapshot: prod.code,
      companyNameSnapshot: prod.company?.name || 'عام',
      purchaseUnit: "كرتونة", // Default
      unitPriceSnapshot: prod.cartonPrice,
      quantity: newQuantity,
      discount: 0
    }]);
  };

  const handleUpdateItem = (index: number, field: string, value: any) => {
    const newItems = [...items];
    newItems[index][field] = value;
    
    // Auto update price if unit changes
    if (field === "purchaseUnit") {
      const prod = allProducts.find(p => p.id === newItems[index].productId);
      if (prod) {
        newItems[index].unitPriceSnapshot = value === "كرتونة" ? prod.cartonPrice : prod.piecePrice;
      }
    }
    
    setItems(newItems);
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    setSaving(true);
    await saveInvoice(order.id, items, invoiceDiscount);
    setSaving(false);
    alert("تم حفظ الفاتورة بنجاح");
  };

  const grossTotal = items.reduce((acc, item) => acc + (item.unitPriceSnapshot * item.quantity), 0);
  const totalItemDiscounts = items.reduce((acc, item) => acc + (item.discount || 0), 0);
  const finalAmount = Math.max(0, grossTotal - totalItemDiscounts - invoiceDiscount);

  // Send to WhatsApp
  const sendWhatsApp = () => {
    let msg = `*فاتورة طلب رقم:* ${order.orderNumber}\n\n`;
    items.forEach(item => {
      msg += `- ${item.productNameSnapshot} (${item.quantity} ${item.purchaseUnit})\n`;
      if (item.discount > 0) msg += `  خصم: ${item.discount} ج.م\n`;
    });
    msg += `\n*الإجمالي قبل الخصم:* ${grossTotal} ج.م`;
    if (totalItemDiscounts + invoiceDiscount > 0) {
      msg += `\n*إجمالي الخصومات:* ${totalItemDiscounts + invoiceDiscount} ج.م`;
    }
    msg += `\n*الإجمالي النهائي المطلوب:* ${finalAmount} ج.م\n\n`;
    msg += `شكراً لتعاملكم معنا.`;
    
    // We send to the customer's phone
    const formattedPhone = order.customerPhone.replace(/^0/, '+20');
    window.open(`https://wa.me/${formattedPhone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      
      {/* Add New Item */}
      <div className="flex gap-4 items-end bg-gray-50 p-4 rounded-lg mb-6 border border-gray-200 relative">
        <div className="flex-1 relative">
          <label className="block text-xs font-bold text-gray-700 mb-1">إضافة منتج للفاتورة (ابحث بالاسم، الكود، الشركة)</label>
          <input 
            type="text" 
            className="w-full p-2 border border-gray-300 rounded outline-none"
            placeholder="ابحث لاختيار منتج..."
            value={productSearch}
            onChange={e => {
              setProductSearch(e.target.value);
              setShowProductDropdown(true);
            }}
            onFocus={() => setShowProductDropdown(true)}
          />
          {showProductDropdown && (
            <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-y-auto">
              {filteredProducts.map(p => (
                <div 
                  key={p.id} 
                  className="p-2 border-b border-gray-100 hover:bg-red-50 cursor-pointer flex justify-between items-center"
                  onClick={() => {
                    setSelectedProductId(p.id.toString());
                    setProductSearch(p.name);
                    setShowProductDropdown(false);
                  }}
                >
                  <div>
                    <div className="font-bold text-sm text-gray-900">{p.name}</div>
                    <div className="text-[10px] text-gray-500">{p.company?.name} {p.code && `| ${p.code}`}</div>
                  </div>
                  <div className="text-primary font-bold text-xs">{p.cartonPrice} ج.م</div>
                </div>
              ))}
              {filteredProducts.length === 0 && (
                <div className="p-3 text-center text-sm text-gray-500">لا توجد نتائج</div>
              )}
            </div>
          )}
        </div>
        <div className="w-24">
          <label className="block text-xs font-bold text-gray-700 mb-1">الكمية</label>
          <input type="number" min="1" className="w-full p-2 border border-gray-300 rounded outline-none" value={newQuantity} onChange={e => setNewQuantity(parseInt(e.target.value))} />
        </div>
        <button 
          onClick={() => {
            handleAddItem();
            setProductSearch("");
            setSelectedProductId("");
          }} 
          className="bg-primary text-white p-2 px-4 rounded hover:bg-red-600 flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> إضافة
        </button>
      </div>

      {/* Items Table */}
      <table className="w-full text-right mb-6">
        <thead className="bg-gray-100 text-gray-600 text-sm">
          <tr>
            <th className="p-2">المنتج</th>
            <th className="p-2">الوحدة</th>
            <th className="p-2 w-20">السعر</th>
            <th className="p-2 w-20">الكمية</th>
            <th className="p-2 w-24">خصم (ج.م)</th>
            <th className="p-2 w-24">الصافي</th>
            <th className="p-2 w-10"></th>
          </tr>
        </thead>
        <tbody>
          {items.map((item, index) => {
            const subtotal = item.unitPriceSnapshot * item.quantity;
            const net = Math.max(0, subtotal - (item.discount || 0));
            return (
              <tr key={index} className="border-b border-gray-100">
                <td className="p-2 text-sm">
                  {item.productNameSnapshot}
                  <div className="text-[10px] text-gray-500">{item.companyNameSnapshot}</div>
                </td>
                <td className="p-2">
                  <select 
                    className="p-1 border border-gray-200 rounded text-sm outline-none"
                    value={item.purchaseUnit}
                    onChange={e => handleUpdateItem(index, 'purchaseUnit', e.target.value)}
                  >
                    <option value="كرتونة">كرتونة</option>
                    <option value="قطعة">قطعة</option>
                  </select>
                </td>
                <td className="p-2">
                  <input type="number" className="w-full p-1 border border-gray-200 rounded text-sm outline-none" value={item.unitPriceSnapshot} onChange={e => handleUpdateItem(index, 'unitPriceSnapshot', parseFloat(e.target.value))} />
                </td>
                <td className="p-2">
                  <input type="number" min="1" className="w-full p-1 border border-gray-200 rounded text-sm outline-none" value={item.quantity} onChange={e => handleUpdateItem(index, 'quantity', parseInt(e.target.value))} />
                </td>
                <td className="p-2">
                  <input type="number" min="0" className="w-full p-1 border text-red-500 border-gray-200 rounded text-sm outline-none" value={item.discount} onChange={e => handleUpdateItem(index, 'discount', parseFloat(e.target.value))} />
                </td>
                <td className="p-2 font-bold text-gray-800">{net}</td>
                <td className="p-2">
                  <button onClick={() => handleRemoveItem(index)} className="text-gray-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      {/* Totals */}
      <div className="flex justify-end mb-6">
        <div className="w-64 bg-gray-50 p-4 rounded-xl border border-gray-200">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>الإجمالي:</span>
            <span>{grossTotal} ج.م</span>
          </div>
          <div className="flex justify-between items-center text-sm text-red-500 mb-2">
            <span>خصم إضافي ع الفاتورة:</span>
            <input type="number" min="0" className="w-20 p-1 border border-red-200 rounded text-left outline-none" value={invoiceDiscount} onChange={e => setInvoiceDiscount(parseFloat(e.target.value))} />
          </div>
          <hr className="my-2 border-gray-200" />
          <div className="flex justify-between font-bold text-lg text-primary">
            <span>الصافي المطلوب:</span>
            <span>{finalAmount} ج.م</span>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-4">
        <button 
          onClick={handleSave} 
          disabled={saving}
          className="flex-1 bg-primary text-white py-3 rounded-lg font-bold flex justify-center items-center gap-2 hover:bg-red-600 disabled:opacity-50"
        >
          {saving ? 'جاري الحفظ...' : <><Save className="w-5 h-5" /> حفظ الفاتورة</>}
        </button>
        <button 
          onClick={sendWhatsApp}
          className="flex-1 bg-green-500 text-white py-3 rounded-lg font-bold flex justify-center items-center gap-2 hover:bg-green-600"
        >
          <MessageCircle className="w-5 h-5" /> إرسال للعميل (واتساب)
        </button>
      </div>

    </div>
  );
}
