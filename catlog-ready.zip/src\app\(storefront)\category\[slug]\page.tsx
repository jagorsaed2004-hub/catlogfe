import { prisma } from "@/lib/prisma";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Heart } from "lucide-react";

export default async function CategoryProductsPage({ params }: { params: { slug: string } }) {
  const decodedSlug = decodeURIComponent(params.slug);
  
  const category = await prisma.globalCategory.findUnique({
    where: { slug: decodedSlug },
    include: {
      products: {
        where: { isActive: true },
        orderBy: { createdAt: 'desc' },
        include: { company: true }
      }
    }
  });

  if (!category) {
    return (
      <div className="p-8 text-center min-h-[60vh] flex flex-col items-center justify-center">
        <h1 className="text-2xl font-bold mb-4">القسم غير موجود</h1>
        <Link href="/" className="text-primary underline">العودة للرئيسية</Link>
      </div>
    );
  }

  return (
    <div className="p-4 mb-20 lg:mb-0 min-h-screen">
      <div className="flex items-center mb-6">
        <Link href="/" className="p-2 -ml-2 text-gray-600 hover:text-gray-900 bg-gray-50 rounded-full ml-4">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold text-gray-900">{category.name}</h1>
        </div>
      </div>

      {category.products.length === 0 ? (
        <div className="text-center py-12 text-gray-500">لا توجد منتجات في هذا القسم حالياً</div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {category.products.map((product) => (
            <div key={product.id} className="bg-white rounded-xl border border-gray-100 flex flex-col overflow-hidden">
              <div className="absolute z-10 p-2">
                <button className="text-gray-400 hover:text-red-500"><Heart className="w-5 h-5" /></button>
              </div>
              <Link href={`/products/${product.id}`} className="h-[140px] bg-[#F8F9FA] relative p-4 flex items-center justify-center">
                 {product.imageUrl ? (
                   <Image src={product.imageUrl} alt={product.name} fill className="object-contain p-4" />
                 ) : (
                   <div className="text-gray-300 text-xs">صورة المنتج</div>
                 )}
              </Link>
              <div className="p-3 flex flex-col flex-1">
                <Link href={`/products/${product.id}`}>
                  <h3 className="font-semibold text-primary text-xs line-clamp-1 mb-1">{product.name}</h3>
                  <p className="text-[10px] text-gray-500">{product.company.name}</p>
                  <p className="font-bold text-gray-900 text-sm mt-1">{product.cartonPrice} ج.م</p>
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
