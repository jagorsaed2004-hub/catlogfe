import { CompanyForm } from "@/components/admin/CompanyForm";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default function NewCompanyPage() {
  return (
    <div>
      <div className="flex items-center mb-6">
        <Link href="/admin/companies" className="p-2 -ml-2 text-gray-600 hover:text-gray-900 bg-gray-50 rounded-full ml-4">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold">إضافة شركة جديدة</h1>
      </div>
      <CompanyForm />
    </div>
  );
}
