"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";

export async function updateSettings(formData: FormData) {
  const settingsToUpdate = [
    { key: 'DEFAULT_WHATSAPP_NUMBER', value: formData.get('whatsappNumber') as string },
    { key: 'DEFAULT_CURRENCY', value: formData.get('currency') as string },
    { key: 'DEFAULT_COMPANY_NAME', value: formData.get('companyName') as string },
  ];

  for (const s of settingsToUpdate) {
    if (s.value) {
      await prisma.setting.upsert({
        where: { key: s.key },
        update: { value: s.value },
        create: { key: s.key, value: s.value }
      });
    }
  }

  revalidatePath('/admin/settings');
  revalidatePath('/'); // to update UI if needed
  
  return { success: true };
}
