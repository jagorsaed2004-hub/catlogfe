"use client";

import { useState } from "react";
import Image from "next/image";
import { Upload, X, Loader2 } from "lucide-react";

export function ImageUpload({ 
  value, 
  onChange 
}: { 
  value?: string | null, 
  onChange: (url: string) => void 
}) {
  const [loading, setLoading] = useState(false);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData
      });
      const data = await res.json();
      if (data.url) {
        onChange(data.url);
      }
    } catch (error) {
      alert("حدث خطأ أثناء رفع الصورة");
    } finally {
      setLoading(false);
    }
  };

  if (value) {
    return (
      <div className="relative w-32 h-32 rounded-lg border border-gray-200 overflow-hidden group">
        <Image src={value} alt="Uploaded" fill className="object-contain" />
        <button 
          type="button"
          onClick={() => onChange("")}
          className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <label className="flex flex-col items-center justify-center w-32 h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 relative">
      {loading ? (
        <Loader2 className="w-6 h-6 text-primary animate-spin" />
      ) : (
        <>
          <Upload className="w-6 h-6 text-gray-400 mb-2" />
          <span className="text-xs text-gray-500">رفع صورة</span>
        </>
      )}
      <input type="file" className="hidden" accept="image/*" onChange={handleUpload} disabled={loading} />
    </label>
  );
}
