import { AdminProvider } from "@/components/admin/AdminProvider";
import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);

  return (
    <AdminProvider>
      <div className="flex h-screen bg-gray-100">
        {/* Sidebar */}
        <aside className="w-64 bg-white shadow-md flex flex-col">
          <div className="p-4 bg-primary text-white font-bold text-lg">
            لوحة الإدارة
          </div>
          <nav className="flex-1 p-4 space-y-2">
            <Link href="/admin" className="block p-2 rounded hover:bg-gray-100">لوحة التحكم</Link>
            <Link href="/admin/products" className="block p-2 rounded hover:bg-gray-100">المنتجات</Link>
            <Link href="/admin/companies" className="block p-2 rounded hover:bg-gray-100">الشركات</Link>
            <Link href="/admin/categories" className="block p-2 rounded hover:bg-gray-100">الأقسام</Link>
            <Link href="/admin/business" className="block p-2 rounded hover:bg-gray-100">المحلات (نشاطات العملاء)</Link>
            <Link href="/admin/orders" className="block p-2 rounded hover:bg-gray-100">الطلبات</Link>
            <hr className="my-2 border-gray-200" />
            <Link href="/admin/import/products" className="block p-2 rounded hover:bg-gray-100 text-sm">استيراد منتجات (Excel)</Link>
            <Link href="/admin/import/prices" className="block p-2 rounded hover:bg-gray-100 text-sm">تحديث أسعار (Excel)</Link>
            <hr className="my-2 border-gray-200" />
            <Link href="/admin/settings" className="block p-2 rounded hover:bg-gray-100">الإعدادات</Link>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-8">
          {children}
        </main>
      </div>
    </AdminProvider>
  );
}
