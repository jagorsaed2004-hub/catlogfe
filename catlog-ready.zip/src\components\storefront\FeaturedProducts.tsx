"use client";

import { SectionHeader } from "./SectionHeader";
import Link from "next/link";
import Image from "next/image";
import { Heart, ShoppingCart } from "lucide-react";
import { useCartStore } from "@/store/cartStore";
import { useState } from "react";

export function FeaturedProducts({ products }: { products: any[] }) {
  const addItem = useCartStore((state) => state.addItem);
  const [addedId, setAddedId] = useState<number | null>(null);

  const handleAdd = (product: any) => {
    addItem({
      productId: product.id,
      name: product.name,
      code: product.code || "",
      companyName: product.company?.name || "عام",
      imageUrl: product.imageUrl,
      unit: "carton", // Default to carton for quick add
      unitPrice: product.cartonPrice,
      quantity: 1,
    });
    
    setAddedId(product.id);
    setTimeout(() => setAddedId(null), 2000);
  };

  return (
    <section>
      <SectionHeader title="منتجات مميزة" href="/products?featured=true" />
      
      <div className="flex overflow-x-auto gap-4 px-4 pb-4 snap-x hide-scrollbar">
        {products.map((product) => (
          <div 
            key={product.id} 
            className="flex-shrink-0 w-[160px] snap-start bg-white rounded-xl border border-gray-100 flex flex-col overflow-hidden"
          >
            {/* Heart Icon */}
            <div className="absolute z-10 p-2">
              <button className="text-gray-400 hover:text-red-500">
                <Heart className="w-5 h-5" />
              </button>
            </div>
            
            {/* Image */}
            <Link href={`/products/${product.id}`} className="h-[140px] bg-[#F8F9FA] relative p-4 flex items-center justify-center">
               {product.imageUrl ? (
                 <Image src={product.imageUrl} alt={product.name} fill className="object-contain p-4" />
               ) : (
                 <div className="text-gray-300 text-xs">صورة المنتج</div>
               )}
            </Link>

            {/* Details */}
            <div className="p-3 flex flex-col flex-1">
              <Link href={`/products/${product.id}`}>
                <h3 className="font-semibold text-primary text-xs line-clamp-1 mb-1">{product.name}</h3>
                <p className="text-[10px] text-gray-500">سعر الكرتونة</p>
                <p className="font-bold text-gray-900 text-sm mt-1">{product.cartonPrice} ج.م</p>
              </Link>
            </div>

            {/* Add to cart */}
            <div className="px-3 pb-3">
              <button 
                onClick={() => handleAdd(product)}
                className={`w-full flex items-center justify-center py-2 rounded-md transition-colors group ${
                  addedId === product.id 
                    ? 'bg-green-500 text-white' 
                    : 'bg-[#E8F0FE] text-primary hover:bg-primary hover:text-white'
                }`}
              >
                <span className="text-xs font-bold mr-2">
                  {addedId === product.id ? "تمت الإضافة" : "أضف للسلة"}
                </span>
                {addedId !== product.id && <ShoppingCart className="w-4 h-4 text-primary group-hover:text-white" />}
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
