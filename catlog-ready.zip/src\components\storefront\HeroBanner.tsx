"use client";

import { CheckCircle2, Truck, Tag, ChevronLeft } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

export function HeroBanner() {
  return (
    <div className="px-4 py-4 mt-2">
      <div className="bg-[#E4C59E] rounded-xl overflow-hidden relative" style={{ backgroundColor: '#D4C3AD' }}>
        {/* Background Image / Pattern can go here */}
        <div className="absolute inset-0 bg-gradient-to-l from-[#C6B49D] to-[#E6D5C3]" />
        
        <div className="relative p-6 flex flex-col items-start justify-center min-h-[220px]">
          <h2 className="text-primary font-extrabold text-2xl mb-4 leading-snug w-2/3">
            كل احتياجات مطعمك<br/>من التعبئة والتغليف
          </h2>
          
          <div className="flex gap-4 mb-6">
            <div className="flex flex-col items-center">
              <CheckCircle2 className="w-5 h-5 text-gray-800 mb-1" />
              <span className="text-[10px] font-bold text-gray-800">جودة عالية</span>
            </div>
            <div className="flex flex-col items-center">
              <Truck className="w-5 h-5 text-gray-800 mb-1" />
              <span className="text-[10px] font-bold text-gray-800">توصيل سريع</span>
            </div>
            <div className="flex flex-col items-center">
              <Tag className="w-5 h-5 text-gray-800 mb-1" />
              <span className="text-[10px] font-bold text-gray-800">أسعار مناسبة</span>
            </div>
          </div>

          <Link href="/products" className="bg-primary text-white flex items-center px-6 py-2 rounded-full font-bold text-sm hover:bg-opacity-90 transition-all">
            تصفح المنتجات
            <ChevronLeft className="w-4 h-4 mr-2" />
          </Link>
        </div>

        {/* Decorative elements / Product images as per reference */}
        {/* We would use actual transparent PNGs here */}
        <div className="absolute top-0 left-0 h-full w-1/3 flex items-end justify-start opacity-80 pointer-events-none">
          {/* Mock image position */}
          <div className="w-full h-full bg-contain bg-no-repeat bg-bottom opacity-50" style={{ backgroundImage: 'url(/images/placeholder.png)' }}></div>
        </div>

        {/* Slider Dots */}
        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex gap-1.5">
          <div className="w-2 h-2 rounded-full bg-primary"></div>
          <div className="w-2 h-2 rounded-full bg-white opacity-70"></div>
          <div className="w-2 h-2 rounded-full bg-white opacity-70"></div>
        </div>
      </div>
    </div>
  );
}
