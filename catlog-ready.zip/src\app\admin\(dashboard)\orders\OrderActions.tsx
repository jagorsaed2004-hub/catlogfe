"use client";

import { useState } from "react";
import { updateOrderStatus } from "./actions";

export function OrderActions({ orderId, currentStatus }: { orderId: number, currentStatus: string }) {
  const [loading, setLoading] = useState(false);

  const handleChange = async (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newStatus = e.target.value;
    if (newStatus === currentStatus) return;
    
    setLoading(true);
    await updateOrderStatus(orderId, newStatus);
    setLoading(false);
  };

  return (
    <select 
      disabled={loading}
      value={currentStatus}
      onChange={handleChange}
      className={`text-xs font-bold rounded-md px-2 py-1 outline-none border cursor-pointer ${
        currentStatus === 'new' ? 'bg-blue-50 text-blue-800 border-blue-200' : 
        currentStatus === 'completed' ? 'bg-green-50 text-green-800 border-green-200' : 
        'bg-red-50 text-red-800 border-red-200'
      }`}
    >
      <option value="new">تحت التجهيز</option>
      <option value="completed">تم التوصيل</option>
      <option value="cancelled">إلغاء الطلب</option>
    </select>
  );
}
