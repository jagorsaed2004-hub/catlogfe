"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";

export async function saveInvoice(orderId: number, items: any[], invoiceDiscount: number) {
  // Compute new gross total and net total
  let grossTotal = 0;
  
  const mappedItems = items.map(item => {
    const subtotal = item.unitPriceSnapshot * item.quantity;
    const finalSubtotal = Math.max(0, subtotal - (item.discount || 0));
    grossTotal += subtotal;
    return {
      id: item.id, // if new, might be undefined
      productId: item.productId,
      productNameSnapshot: item.productNameSnapshot,
      productCodeSnapshot: item.productCodeSnapshot,
      companyNameSnapshot: item.companyNameSnapshot,
      purchaseUnit: item.purchaseUnit,
      unitPriceSnapshot: item.unitPriceSnapshot,
      quantity: item.quantity,
      subtotal,
      discount: item.discount || 0,
      finalSubtotal
    };
  });

  const finalAmount = Math.max(0, mappedItems.reduce((acc, item) => acc + item.finalSubtotal, 0) - invoiceDiscount);

  // Use a transaction: Delete old items, create new items, update order
  await prisma.$transaction(async (tx) => {
    // delete all current items
    await tx.orderItem.deleteMany({ where: { orderId } });
    
    // create new items
    await tx.orderItem.createMany({
      data: mappedItems.map(item => ({
        orderId,
        productId: item.productId,
        productNameSnapshot: item.productNameSnapshot,
        productCodeSnapshot: item.productCodeSnapshot,
        companyNameSnapshot: item.companyNameSnapshot,
        purchaseUnit: item.purchaseUnit,
        unitPriceSnapshot: item.unitPriceSnapshot,
        quantity: item.quantity,
        subtotal: item.subtotal,
        discount: item.discount,
        finalSubtotal: item.finalSubtotal
      }))
    });

    // update order
    await tx.order.update({
      where: { id: orderId },
      data: {
        totalAmount: grossTotal,
        discount: invoiceDiscount,
        finalAmount: finalAmount,
      }
    });
  });

  revalidatePath("/admin/orders");
  revalidatePath(`/admin/orders/${orderId}`);
  return { success: true };
}
