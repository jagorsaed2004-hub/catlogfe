import { NextResponse } from "next/dist/server/web/spec-extension/response";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  try {
    const { items } = await req.json();

    if (!items || !Array.isArray(items)) {
      return NextResponse.json({ error: "Invalid data format" }, { status: 400 });
    }

    let successCount = 0;
    let failedCount = 0;
    let errors: any[] = [];

    for (const item of items) {
      try {
        const { code, name, companyName, categoryName, classificationName, piecesPerCarton, cartonPrice } = item;

        if (!name || !cartonPrice) {
          failedCount++;
          errors.push(`منتج بدون اسم أو سعر`);
          continue;
        }

        // 1. Find or create Company
        let companyId = null;
        if (companyName) {
          const slug = companyName.trim().replace(/\s+/g, '-').toLowerCase();
          const company = await prisma.company.upsert({
            where: { slug: slug },
            update: {},
            create: { name: companyName.trim(), slug: slug },
          });
          companyId = company.id;
        }

        // 2. Find or create Category
        let globalCategoryId = null;
        if (categoryName) {
          const slug = categoryName.trim().replace(/\s+/g, '-').toLowerCase();
          const category = await prisma.globalCategory.upsert({
            where: { slug: slug },
            update: {},
            create: { name: categoryName.trim(), slug: slug },
          });
          globalCategoryId = category.id;
        }

        // 3. Find or create Classification
        let classificationId = null;
        if (classificationName && globalCategoryId) {
          const slug = classificationName.trim().replace(/\s+/g, '-').toLowerCase();
          const classification = await prisma.productClassification.upsert({
            where: { slug: slug },
            update: {},
            create: { name: classificationName.trim(), slug: slug, globalCategoryId },
          });
          classificationId = classification.id;
        }

        const pieces = parseInt(piecesPerCarton) || 1;
        const price = parseFloat(cartonPrice);
        const pieceP = price / pieces;

        const internalCode = code ? code.toString() : `IT-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
        const productCode = code ? code.toString() : internalCode;

        // 4. Upsert Product
        await prisma.product.upsert({
          where: { internalCode: productCode }, // We use internalCode as unique identifier here if code might be duplicated, but code is unique in schema.
          update: {
            name: name,
            companyId: companyId || undefined,
            globalCategoryId: globalCategoryId || undefined,
            classificationId: classificationId || undefined,
            piecesPerCarton: pieces,
            cartonPrice: price,
            piecePrice: pieceP,
            code: productCode,
          },
          create: {
            internalCode: productCode,
            code: productCode,
            name: name,
            companyId: companyId || 1, // Fallback to first company if none
            globalCategoryId: globalCategoryId || undefined,
            classificationId: classificationId || undefined,
            piecesPerCarton: pieces,
            cartonPrice: price,
            piecePrice: pieceP,
          }
        });

        successCount++;
      } catch (err: any) {
        failedCount++;
        errors.push(`خطأ في السطر: ${item.name} - ${err.message}`);
      }
    }

    return NextResponse.json({
      success: true,
      message: `تم استيراد ${successCount} منتج بنجاح، وفشل ${failedCount}.`,
      successCount,
      failedCount,
      errors
    });

  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
