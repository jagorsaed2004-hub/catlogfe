import { NextResponse } from "next/dist/server/web/spec-extension/response";
import { prisma } from "@/lib/prisma";

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  try {
    const data = await req.json();
    const { businessTypeIds, ...productData } = data;

    if (productData.companyId) productData.companyId = parseInt(productData.companyId);
    if (productData.globalCategoryId) productData.globalCategoryId = parseInt(productData.globalCategoryId);

    // Only update mappings if businessTypeIds is explicitly provided
    if (businessTypeIds !== undefined) {
      await prisma.businessTypeProduct.deleteMany({
        where: { productId: parseInt(params.id) }
      });
      
      productData.businessTypeProducts = {
        create: businessTypeIds.map((id: string) => ({
          businessTypeId: parseInt(id)
        }))
      };
    }

    const product = await prisma.product.update({
      where: { id: parseInt(params.id) },
      data: productData
    });

    return NextResponse.json({ success: true, product });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
