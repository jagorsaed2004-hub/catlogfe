"use client";

import { MessageCircle } from "lucide-react";

export function WhatsAppFAB({ phoneNumber }: { phoneNumber: string }) {
  return (
    <div className="fixed bottom-20 left-4 z-50 flex items-center lg:bottom-8 lg:left-8 group">
      {/* Label (Only shows on larger screens or when hovered, depending on preference. Design shows it next to it) */}
      <div className="bg-white px-3 py-2 rounded-lg shadow-md text-sm font-medium text-gray-700 ml-3 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap hidden sm:block">
        تواصل معنا<br/>عبر واتساب
      </div>
      
      <a 
        href={`https://wa.me/${phoneNumber}`} 
        target="_blank" 
        rel="noopener noreferrer"
        className="bg-whatsapp text-white p-4 rounded-full shadow-lg hover:scale-105 transition-transform flex items-center justify-center"
      >
        <MessageCircle className="w-8 h-8 fill-current" />
      </a>
    </div>
  );
}
