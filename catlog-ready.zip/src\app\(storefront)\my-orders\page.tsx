"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, RefreshCcw, Package } from "lucide-react";
import Link from "next/link";
import { useCartStore } from "@/store/cartStore";

export default function MyOrdersPage() {
  const router = useRouter();
  const [phone, setPhone] = useState("");
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  
  const clearCart = useCartStore(state => state.clearCart);
  const addItem = useCartStore(state => state.addItem);

  useEffect(() => {
    const savedPhone = localStorage.getItem('customerPhone');
    if (savedPhone) {
      setPhone(savedPhone);
      fetchOrders(savedPhone);
    }
  }, []);

  const fetchOrders = async (phoneNumber: string) => {
    if (!phoneNumber) return;
    setLoading(true);
    setSearched(true);
    try {
      const res = await fetch(`/api/my-orders?phone=${phoneNumber}`);
      const data = await res.json();
      setOrders(data.orders || []);
      localStorage.setItem('customerPhone', phoneNumber);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleReorder = (order: any) => {
    // Clear current cart and add all items from this order
    clearCart();
    
    order.items.forEach((item: any) => {
      addItem({
        productId: item.productId,
        name: item.productNameSnapshot,
        code: item.productCodeSnapshot || "",
        companyName: item.companyNameSnapshot,
        unit: item.purchaseUnit,
        unitPrice: item.unitPriceSnapshot,
        quantity: item.quantity
      });
    });

    // Navigate to cart to let them edit/confirm
    router.push('/cart');
  };

  return (
    <div className="p-4 mb-20 lg:mb-0 min-h-screen bg-gray-50">
      <div className="flex items-center mb-6">
        <Link href="/" className="p-2 -ml-2 text-gray-600 hover:text-gray-900 bg-white rounded-full ml-4 shadow-sm">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold text-gray-900">طلباتي السابقة</h1>
      </div>

      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 mb-6">
        <label className="block text-sm font-bold text-gray-700 mb-2">رقم الجوال للبحث عن طلباتك</label>
        <div className="flex gap-2">
          <input 
            type="tel" 
            placeholder="05XXXXXXXX"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="flex-1 border border-gray-300 rounded-lg px-4 py-3 text-left dir-ltr focus:ring-2 focus:ring-primary focus:border-transparent"
          />
          <button 
            onClick={() => fetchOrders(phone)}
            disabled={loading}
            className="bg-primary text-white px-6 py-3 rounded-lg font-bold hover:bg-opacity-90 transition-all disabled:opacity-50"
          >
            {loading ? "جاري البحث..." : "بحث"}
          </button>
        </div>
      </div>

      {searched && !loading && orders.length === 0 && (
        <div className="text-center py-12">
          <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-lg font-bold text-gray-700">لا توجد طلبات سابقة</h2>
          <p className="text-gray-500 mt-2">لم نتمكن من العثور على أي طلبات مسجلة برقم الجوال هذا.</p>
        </div>
      )}

      <div className="space-y-4">
        {orders.map((order) => (
          <div key={order.id} className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
            <div className="flex justify-between items-start mb-4 pb-4 border-b border-gray-100">
              <div>
                <span className="text-xs text-gray-500 block mb-1">رقم الطلب: {order.orderNumber}</span>
                <span className="font-bold text-lg text-primary">{order.totalAmount} ج.م</span>
              </div>
              <div className="text-left">
                <span className="text-xs text-gray-500 block mb-1">
                  {new Date(order.createdAt).toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' })}
                </span>
                <span className={`text-xs px-2 py-1 rounded-md font-bold ${
                  order.status === 'new' ? 'bg-blue-50 text-blue-700' : 
                  order.status === 'completed' ? 'bg-green-50 text-green-700' : 
                  'bg-red-50 text-red-700'
                }`}>
                  {order.status === 'new' ? 'تحت التجهيز' : order.status === 'completed' ? 'تم التوصيل' : 'تم الإلغاء'}
                </span>
              </div>
            </div>

            <div className="mb-4">
              <h4 className="font-bold text-sm mb-2 text-gray-700">المنتجات ({order.items.length}):</h4>
              <ul className="space-y-2">
                {order.items.slice(0, 3).map((item: any, idx: number) => (
                  <li key={idx} className="text-sm flex justify-between text-gray-600">
                    <span className="truncate flex-1 pl-4">{item.quantity}x {item.productNameSnapshot}</span>
                    <span className="font-medium whitespace-nowrap">{item.subtotal} ج.م</span>
                  </li>
                ))}
                {order.items.length > 3 && (
                  <li className="text-xs text-gray-400">... و {order.items.length - 3} منتجات أخرى</li>
                )}
              </ul>
            </div>

            <button 
              onClick={() => handleReorder(order)}
              className="w-full bg-[#E8F0FE] text-primary py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-primary hover:text-white transition-colors"
            >
              <RefreshCcw className="w-5 h-5" />
              إعادة الطلب والتعديل عليه
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
