import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { InlineImageUpload } from "@/components/admin/InlineImageUpload";

export default async function CategoriesPage() {
  const categories = await prisma.globalCategory.findMany({
    orderBy: { sortOrder: 'asc' }
  });

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">الأقسام</h1>
        <Link 
          href="/admin/categories/new"
          className="bg-primary text-white px-4 py-2 rounded-md hover:bg-opacity-90"
        >
          إضافة قسم
        </Link>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200 text-right">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">القسم</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">الاسم البرمجي (Slug)</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">الترتيب</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">الحالة</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {categories.map((category) => (
              <tr key={category.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <InlineImageUpload 
                      currentUrl={category.imageUrl} 
                      entityType="categories" 
                      entityId={category.id}
                    />
                    <div className="mr-4">
                      <div className="text-sm font-medium text-gray-900">{category.name}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {category.slug}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {category.sortOrder}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${category.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {category.isActive ? 'نشط' : 'مخفي'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <Link href={`/admin/categories/${category.id}/edit`} className="text-primary hover:text-opacity-80">تعديل</Link>
                </td>
              </tr>
            ))}
            {categories.length === 0 && (
              <tr>
                <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500">
                  لا توجد أقسام حتى الآن
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
