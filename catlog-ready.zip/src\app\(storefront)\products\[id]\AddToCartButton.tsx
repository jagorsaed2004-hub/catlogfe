"use client";

import { useState } from "react";
import { useCartStore } from "@/store/cartStore";
import { ShoppingCart, Plus, Minus } from "lucide-react";

export function AddToCartButton({ product }: { product: any }) {
  const addItem = useCartStore((state) => state.addItem);
  const [quantity, setQuantity] = useState(1);
  const [unit, setUnit] = useState<"carton" | "piece">("carton");
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    addItem({
      productId: product.id,
      name: product.name,
      code: product.code || "",
      companyName: product.company.name,
      imageUrl: product.imageUrl,
      unit,
      unitPrice: unit === "carton" ? product.cartonPrice : product.piecePrice,
      quantity,
    });
    
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="fixed bottom-16 left-0 w-full bg-white border-t border-gray-100 p-4 lg:static lg:border-none lg:p-0 z-40">
      
      <div className="flex gap-4 mb-4">
        <label className={`flex-1 border rounded-lg p-3 text-center cursor-pointer transition-colors ${unit === 'carton' ? 'bg-primary text-white border-primary' : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'}`}>
          <input type="radio" className="hidden" checked={unit === 'carton'} onChange={() => setUnit('carton')} />
          <span className="block font-bold mb-1">بالكرتونة</span>
          <span className="text-xs">{product.cartonPrice} ج.م</span>
        </label>
        <label className={`flex-1 border rounded-lg p-3 text-center cursor-pointer transition-colors ${unit === 'piece' ? 'bg-primary text-white border-primary' : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'}`}>
          <input type="radio" className="hidden" checked={unit === 'piece'} onChange={() => setUnit('piece')} />
          <span className="block font-bold mb-1">بالقطعة</span>
          <span className="text-xs">{product.piecePrice} ج.م</span>
        </label>
      </div>

      <div className="flex gap-4 h-12">
        <div className="w-1/3 flex items-center justify-between bg-gray-50 rounded-lg border border-gray-200 px-2">
          <button 
            onClick={() => setQuantity(Math.max(1, quantity - 1))}
            className="p-2 text-gray-600 hover:text-primary"
          >
            <Minus className="w-5 h-5" />
          </button>
          <span className="font-bold text-lg">{quantity}</span>
          <button 
            onClick={() => setQuantity(quantity + 1)}
            className="p-2 text-gray-600 hover:text-primary"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
        
        <button 
          onClick={handleAdd}
          className={`flex-1 rounded-lg font-bold text-lg flex items-center justify-center transition-all ${added ? 'bg-green-500 text-white' : 'bg-primary text-white hover:bg-opacity-90'}`}
        >
          {added ? "تمت الإضافة بنجاح!" : (
            <>
              أضف للسلة
              <ShoppingCart className="w-5 h-5 mr-2" />
            </>
          )}
        </button>
      </div>
    </div>
  );
}
