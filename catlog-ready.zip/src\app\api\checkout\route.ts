import { NextResponse } from "next/dist/server/web/spec-extension/response";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { phone, items, totalAmount } = body;

    if (!phone || !items || items.length === 0) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const orderNumber = `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const order = await prisma.order.create({
      data: {
        orderNumber,
        customerPhone: phone,
        totalAmount,
        finalAmount: totalAmount,
        discount: 0,
        status: 'new',
        items: {
          create: items.map((item: any) => ({
            productId: item.productId,
            productNameSnapshot: item.name,
            productCodeSnapshot: item.code,
            companyNameSnapshot: item.companyName,
            purchaseUnit: item.unit,
            unitPriceSnapshot: item.unitPrice,
            quantity: item.quantity,
            subtotal: item.unitPrice * item.quantity,
            finalSubtotal: item.unitPrice * item.quantity,
            discount: 0
          }))
        }
      }
    });

    return NextResponse.json({ success: true, orderId: order.id, orderNumber });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
