import { prisma } from "@/lib/prisma";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Search as SearchIcon, Heart } from "lucide-react";
import { LiveSearchInput } from "@/components/storefront/LiveSearchInput";
import { ProductFilter } from "@/components/storefront/ProductFilter";

export default async function SearchPage({
  searchParams,
}: {
  searchParams: { q?: string, companyId?: string, categoryId?: string };
}) {
  const q = searchParams.q || "";
  const companyId = searchParams.companyId ? parseInt(searchParams.companyId) : undefined;
  const categoryId = searchParams.categoryId ? parseInt(searchParams.categoryId) : undefined;

  const products = q.length >= 2 || companyId || categoryId ? await prisma.product.findMany({
    where: {
      isActive: true,
      ...(companyId ? { companyId } : {}),
      ...(categoryId ? { globalCategoryId: categoryId } : {}),
      ...(q.length >= 2 ? {
        OR: [
          { name: { contains: q } },
          { code: { contains: q } },
        ]
      } : {})
    },
    include: { company: true },
    take: 50
  }) : [];

  const companies = await prisma.company.findMany({ where: { isActive: true }, select: { id: true, name: true } });
  const categories = await prisma.globalCategory.findMany({ where: { isActive: true }, select: { id: true, name: true } });

  return (
    <div className="p-4 mb-20 lg:mb-0 min-h-screen bg-gray-50">
      <div className="flex items-center gap-3 mb-4">
        <Link href="/" className="p-2 -mr-2 text-gray-600 hover:text-gray-900 bg-white shadow-sm rounded-full">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <LiveSearchInput />
      </div>

      <ProductFilter companies={companies} categories={categories} />

      {q && (
        <div className="mb-4">
          <h2 className="text-gray-600 text-sm">نتائج البحث عن: <span className="font-bold text-gray-900">"{q}"</span></h2>
        </div>
      )}

      {(!q && !companyId && !categoryId) ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-4">
            <SearchIcon className="w-8 h-8 text-gray-300" />
          </div>
          <h3 className="font-bold text-lg text-gray-800 mb-2">ابحث في الكتالوج</h3>
          <p className="text-sm text-gray-500">ابحث باسم المنتج أو كود الشركة (اكتب حرفين أو رقمين على الأقل)، أو استخدم الفلاتر للبحث.</p>
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-20 text-gray-500">لا توجد نتائج مطابقة لبحثك</div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {products.map((product) => (
            <div key={product.id} className="bg-white rounded-xl border border-gray-100 flex flex-col overflow-hidden">
              <div className="absolute z-10 p-2">
                <button className="text-gray-400 hover:text-red-500"><Heart className="w-5 h-5" /></button>
              </div>
              <Link href={`/products/${product.id}`} className="h-[140px] bg-[#F8F9FA] relative p-4 flex items-center justify-center">
                 {product.imageUrl ? (
                   <Image src={product.imageUrl} alt={product.name} fill className="object-contain p-4" />
                 ) : (
                   <div className="text-gray-300 text-xs">صورة المنتج</div>
                 )}
              </Link>
              <div className="p-3 flex flex-col flex-1">
                <Link href={`/products/${product.id}`}>
                  <h3 className="font-semibold text-primary text-xs line-clamp-1 mb-1">{product.name}</h3>
                  <p className="text-[10px] text-gray-500">{product.company?.name || 'عام'} {product.code && `| ${product.code}`}</p>
                  <p className="font-bold text-gray-900 text-sm mt-1">{product.cartonPrice} ج.م</p>
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
