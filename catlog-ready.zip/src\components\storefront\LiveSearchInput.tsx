"use client";

import { Search as SearchIcon } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import { useState, useEffect, useRef } from "react";

export function LiveSearchInput() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialQ = searchParams.get('q') || "";
  const [query, setQuery] = useState(initialQ);
  
  // Debounce logic
  useEffect(() => {
    // If less than 2 characters, clear query from URL if it was there
    if (query.length < 2 && query.length > 0) return;
    
    const timeout = setTimeout(() => {
      const params = new URLSearchParams(searchParams.toString());
      if (query.length >= 2) {
        params.set('q', query);
      } else {
        params.delete('q');
      }
      router.replace(`/search?${params.toString()}`, { scroll: false });
    }, 300); // 300ms debounce
    
    return () => clearTimeout(timeout);
  }, [query, router, searchParams]);

  return (
    <div className="flex-1 relative">
      <input 
        type="text" 
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="ابحث عن منتج أو كود (اكتب حرفين على الأقل)..." 
        className="w-full bg-gray-50 border border-gray-200 rounded-full py-3 pr-12 pl-4 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
        autoFocus
      />
      <SearchIcon className="absolute right-4 top-3.5 w-5 h-5 text-gray-400" />
    </div>
  );
}
