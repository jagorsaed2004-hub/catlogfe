import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type PurchaseUnit = 'carton' | 'piece';

export interface CartItem {
  id: string; // unique ID for cart item
  productId: number;
  name: string;
  code: string;
  companyName: string;
  imageUrl?: string;
  unit: PurchaseUnit;
  unitPrice: number;
  quantity: number;
}

interface CartStore {
  items: CartItem[];
  addItem: (item: Omit<CartItem, 'id'>) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  getTotalItems: () => number;
  getTotalPrice: () => number;
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: (item) => set((state) => {
        const existingItem = state.items.find(
          (i) => i.productId === item.productId && i.unit === item.unit
        );

        if (existingItem) {
          return {
            items: state.items.map((i) =>
              i.id === existingItem.id
                ? { ...i, quantity: i.quantity + item.quantity }
                : i
            ),
          };
        }

        return {
          items: [...state.items, { ...item, id: Math.random().toString(36).substr(2, 9) }],
        };
      }),
      removeItem: (id) => set((state) => ({
        items: state.items.filter((i) => i.id !== id)
      })),
      updateQuantity: (id, quantity) => set((state) => ({
        items: state.items.map((i) => (i.id === id ? { ...i, quantity } : i))
      })),
      clearCart: () => set({ items: [] }),
      getTotalItems: () => get().items.reduce((total, item) => total + item.quantity, 0),
      getTotalPrice: () => get().items.reduce((total, item) => total + (item.unitPrice * item.quantity), 0),
    }),
    {
      name: 'cart-storage',
    }
  )
);
