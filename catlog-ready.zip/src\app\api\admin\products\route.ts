import { NextResponse } from "next/dist/server/web/spec-extension/response";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  try {
    const data = await req.json();
    const { businessTypeIds, ...productData } = data;

    if (productData.companyId) productData.companyId = parseInt(productData.companyId);
    if (productData.globalCategoryId) productData.globalCategoryId = parseInt(productData.globalCategoryId);
    
    // Generate internal code if empty
    if (!productData.internalCode) {
      productData.internalCode = `IT-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    }

    const product = await prisma.product.create({
      data: {
        ...productData,
        businessTypeProducts: businessTypeIds && businessTypeIds.length > 0 ? {
          create: businessTypeIds.map((id: string) => ({
            businessTypeId: parseInt(id)
          }))
        } : undefined
      }
    });

    return NextResponse.json({ success: true, product });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
