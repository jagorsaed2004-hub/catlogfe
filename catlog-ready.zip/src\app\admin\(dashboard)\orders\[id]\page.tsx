import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { InvoiceEditor } from "../InvoiceEditor";

export default async function OrderInvoicePage({ params }: { params: { id: string } }) {
  const orderId = parseInt(params.id);

  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: { items: true }
  });

  if (!order) {
    return <div className="p-8">الطلب غير موجود</div>;
  }

  const allProducts = await prisma.product.findMany({
    where: { isActive: true },
    select: { id: true, name: true, code: true, cartonPrice: true, piecePrice: true, company: { select: { name: true } } },
    orderBy: { name: 'asc' }
  });

  const settings = await prisma.setting.findMany();
  const storePhone = settings.find(s => s.key === "DEFAULT_WHATSAPP_NUMBER")?.value || "";

  return (
    <div>
      <div className="flex items-center gap-4 mb-6">
        <Link href="/admin/orders" className="p-2 bg-white border border-gray-200 rounded hover:bg-gray-50">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-2xl font-bold">فاتورة طلب {order.orderNumber}</h1>
          <p className="text-sm text-gray-500 mt-1">هاتف العميل: {order.customerPhone}</p>
        </div>
      </div>

      <InvoiceEditor order={order} allProducts={allProducts} storePhone={storePhone} />
    </div>
  );
}
