import { MetadataRoute } from 'next';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'مستلزمات التعبئة والتغليف',
    short_name: 'التعبئة',
    description: 'متجر متخصص في بيع وتوفير كافة مستلزمات التعبئة والتغليف بجودة عالية وأسعار جملة',
    start_url: '/',
    display: 'standalone',
    background_color: '#ffffff',
    theme_color: '#EF4444', // Tailwind primary (red-500)
    dir: 'rtl',
    lang: 'ar',
    icons: [
      {
        src: '/icon-192x192.png',
        sizes: '192x192',
        type: 'image/png',
      },
      {
        src: '/icon-512x512.png',
        sizes: '512x512',
        type: 'image/png',
      },
      {
        src: '/icon-512x512.png',
        sizes: '512x512',
        type: 'image/png',
        purpose: 'maskable'
      }
    ],
  };
}
