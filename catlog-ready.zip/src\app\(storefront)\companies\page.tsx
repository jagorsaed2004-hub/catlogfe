import { prisma } from "@/lib/prisma";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default async function AllCompaniesPage() {
  const companies = await prisma.company.findMany({
    where: { isActive: true },
    orderBy: { sortOrder: 'asc' }
  });

  return (
    <div className="p-4 mb-20 lg:mb-0 min-h-screen bg-gray-50">
      <div className="flex items-center mb-6">
        <Link href="/" className="p-2 -ml-2 text-gray-600 hover:text-gray-900 bg-white rounded-full ml-4 shadow-sm">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold text-gray-900">جميع الشركات</h1>
      </div>

      <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {companies.map((company) => (
          <Link 
            key={company.id} 
            href={`/company/${company.slug}`}
            className="bg-white rounded-xl border border-gray-100 shadow-sm flex flex-col items-center justify-center p-3 hover:shadow-md transition-shadow aspect-square"
          >
            <div className="h-12 w-full relative mb-2 flex items-center justify-center text-primary">
               {company.logoUrl ? (
                 <Image src={company.logoUrl} alt={company.name} fill className="object-contain" />
               ) : (
                 <span className="text-sm font-bold text-gray-400">{company.name.substring(0,2)}</span>
               )}
            </div>
            <span className="text-xs font-bold text-gray-900 text-center w-full truncate">
              {company.name}
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}
