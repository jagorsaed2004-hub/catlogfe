import { SectionHeader } from "./SectionHeader";
import Link from "next/link";
import Image from "next/image";

export function CompaniesSection({ companies }: { companies: any[] }) {
  // Adding "أخرى" mock item at the end to match reference
  const items = [...companies, { id: 'other', name: 'أخرى', isOther: true }];

  return (
    <section>
      <SectionHeader title="الشركات" href="/companies" />
      
      <div className="flex overflow-x-auto gap-3 px-4 pb-4 snap-x hide-scrollbar">
        {items.map((company) => (
          <Link 
            key={company.id} 
            href={company.isOther ? '/companies' : `/company/${company.slug}`}
            className="flex-shrink-0 w-[80px] h-[90px] snap-start bg-white rounded-xl border border-gray-100 shadow-sm flex flex-col items-center justify-center p-2"
          >
            <div className="h-10 w-full relative mb-2 flex items-center justify-center text-primary">
               {company.isOther ? (
                 <div className="grid grid-cols-2 gap-1 w-6 h-6">
                   <div className="bg-current rounded-[2px]"></div><div className="bg-current rounded-[2px]"></div>
                   <div className="bg-current rounded-[2px]"></div><div className="bg-current rounded-[2px]"></div>
                 </div>
               ) : company.logoUrl ? (
                 <Image src={company.logoUrl} alt={company.name} fill className="object-contain" />
               ) : (
                 <span className="text-xs font-bold">{company.name.substring(0,2)}</span>
               )}
            </div>
            <span className="text-[11px] font-bold text-gray-900 text-center w-full truncate">
              {company.name}
            </span>
          </Link>
        ))}
      </div>
    </section>
  );
}
