import { BusinessForm } from "@/components/admin/BusinessForm";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default async function EditBusinessPage({ params }: { params: { id: string } }) {
  const business = await prisma.businessType.findUnique({
    where: { id: parseInt(params.id) }
  });

  if (!business) {
    return <div className="p-8 text-center">النشاط غير موجود</div>;
  }

  return (
    <div>
      <div className="flex items-center mb-6">
        <Link href="/admin/business" className="p-2 -ml-2 text-gray-600 hover:text-gray-900 bg-gray-50 rounded-full ml-4">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold">تعديل النشاط: {business.name}</h1>
      </div>
      <BusinessForm initialData={business} />
    </div>
  );
}
