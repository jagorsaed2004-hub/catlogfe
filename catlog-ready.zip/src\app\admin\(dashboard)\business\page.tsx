import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { InlineImageUpload } from "@/components/admin/InlineImageUpload";

export default async function BusinessTypesPage() {
  const types = await prisma.businessType.findMany({
    orderBy: { sortOrder: 'asc' }
  });

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">نشاطات العملاء (المحلات)</h1>
        <Link 
          href="/admin/business/new"
          className="bg-primary text-white px-4 py-2 rounded-md hover:bg-opacity-90"
        >
          إضافة نشاط / محل
        </Link>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200 text-right">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">المحل / النشاط</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">الوصف</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">الحالة</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {types.map((type) => (
              <tr key={type.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <InlineImageUpload 
                      currentUrl={type.imageUrl} 
                      entityType="business" 
                      entityId={type.id}
                    />
                    <div className="mr-4">
                      <div className="text-sm font-bold text-gray-900">{type.name}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {type.description}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${type.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {type.isActive ? 'نشط' : 'مخفي'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <Link href={`/admin/business/${type.id}/edit`} className="text-primary hover:text-opacity-80">تعديل</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
