"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ImageUpload } from "./ImageUpload";

export function ProductForm({ 
  initialData = {}, 
  companies = [], 
  categories = [],
  businessTypes = []
}: { 
  initialData?: any,
  companies?: any[],
  categories?: any[],
  businessTypes?: any[]
}) {
  const router = useRouter();
  
  // Extract existing business types if any
  const existingBusinessTypes = initialData.businessTypeProducts?.map((bt: any) => bt.businessTypeId.toString()) || [];

  const [formData, setFormData] = useState({
    name: initialData.name || "",
    code: initialData.code || "",
    internalCode: initialData.internalCode || "",
    companyId: initialData.companyId?.toString() || "",
    globalCategoryId: initialData.globalCategoryId?.toString() || "",
    cartonPrice: initialData.cartonPrice || 0,
    piecePrice: initialData.piecePrice || 0,
    piecesPerCarton: initialData.piecesPerCarton || 1,
    size: initialData.size || "",
    capacity: initialData.capacity || "",
    description: initialData.description || "",
    imageUrl: initialData.imageUrl || "",
    isFeatured: initialData.isFeatured || false,
    isActive: initialData.isActive !== false,
  });

  const [selectedShops, setSelectedShops] = useState<string[]>(existingBusinessTypes);
  const [loading, setLoading] = useState(false);

  const toggleShop = (id: string) => {
    if (selectedShops.includes(id)) {
      setSelectedShops(selectedShops.filter(s => s !== id));
    } else {
      setSelectedShops([...selectedShops, id]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const res = await fetch(`/api/admin/products${initialData.id ? `/${initialData.id}` : ''}`, {
        method: initialData.id ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          businessTypeIds: selectedShops
        })
      });

      if (res.ok) {
        router.push("/admin/products");
        router.refresh();
      } else {
        alert("حدث خطأ أثناء حفظ المنتج");
      }
    } catch (error) {
      alert("حدث خطأ في الاتصال");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      
      <div className="mb-8">
        <label className="block text-sm font-medium text-gray-700 mb-3">صورة المنتج</label>
        <ImageUpload 
          value={formData.imageUrl} 
          onChange={(url) => setFormData({...formData, imageUrl: url})} 
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">اسم المنتج *</label>
          <input 
            type="text" required 
            className="w-full border border-gray-300 rounded-md px-3 py-2"
            value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">كود المنتج (الشركة)</label>
          <input 
            type="text" 
            className="w-full border border-gray-300 rounded-md px-3 py-2"
            value={formData.code} onChange={e => setFormData({...formData, code: e.target.value})}
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">الشركة</label>
          <select 
            className="w-full border border-gray-300 rounded-md px-3 py-2"
            value={formData.companyId} onChange={e => setFormData({...formData, companyId: e.target.value})}
          >
            <option value="">اختر الشركة...</option>
            {companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">القسم العام</label>
          <select 
            className="w-full border border-gray-300 rounded-md px-3 py-2"
            value={formData.globalCategoryId} onChange={e => setFormData({...formData, globalCategoryId: e.target.value})}
          >
            <option value="">اختر القسم...</option>
            {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">سعر الكرتونة (ج.م) *</label>
          <input 
            type="number" step="0.01" required 
            className="w-full border border-gray-300 rounded-md px-3 py-2 text-left" dir="ltr"
            value={formData.cartonPrice} onChange={e => setFormData({...formData, cartonPrice: parseFloat(e.target.value) || 0})}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">سعر القطعة (ج.م) *</label>
          <input 
            type="number" step="0.01" required 
            className="w-full border border-gray-300 rounded-md px-3 py-2 text-left" dir="ltr"
            value={formData.piecePrice} onChange={e => setFormData({...formData, piecePrice: parseFloat(e.target.value) || 0})}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">عدد القطع بالكرتونة *</label>
          <input 
            type="number" required 
            className="w-full border border-gray-300 rounded-md px-3 py-2 text-left" dir="ltr"
            value={formData.piecesPerCarton} onChange={e => setFormData({...formData, piecesPerCarton: parseInt(e.target.value) || 1})}
          />
        </div>
        <div className="flex gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">المقاس</label>
            <input 
              type="text" 
              className="w-full border border-gray-300 rounded-md px-3 py-2"
              placeholder="مثال: 10x15"
              value={formData.size} onChange={e => setFormData({...formData, size: e.target.value})}
            />
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">السعة</label>
            <input 
              type="text" 
              className="w-full border border-gray-300 rounded-md px-3 py-2"
              placeholder="مثال: 12oz"
              value={formData.capacity} onChange={e => setFormData({...formData, capacity: e.target.value})}
            />
          </div>
        </div>

        {/* Business Types Section */}
        <div className="md:col-span-2 mt-4">
          <label className="block text-sm font-bold text-gray-900 mb-3 border-b pb-2">تعيين في المحلات / نشاطات العملاء</label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {businessTypes.map(bt => (
              <label key={bt.id} className={`flex items-center gap-2 p-3 border rounded-lg cursor-pointer transition-colors ${selectedShops.includes(bt.id.toString()) ? 'bg-blue-50 border-blue-200' : 'hover:bg-gray-50'}`}>
                <input 
                  type="checkbox" 
                  className="w-4 h-4 text-primary rounded border-gray-300"
                  checked={selectedShops.includes(bt.id.toString())}
                  onChange={() => toggleShop(bt.id.toString())}
                />
                <span className="text-sm font-medium text-gray-700">{bt.name}</span>
              </label>
            ))}
            {businessTypes.length === 0 && (
              <p className="text-xs text-gray-500">لا توجد محلات/نشاطات مضافة بعد</p>
            )}
          </div>
        </div>
        
        <div className="md:col-span-2 mt-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">الوصف</label>
          <textarea 
            className="w-full border border-gray-300 rounded-md px-3 py-2" rows={3}
            value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})}
          ></textarea>
        </div>

        <div className="md:col-span-2 flex gap-6 mt-4">
          <label className="flex items-center gap-2 cursor-pointer">
            <input 
              type="checkbox" 
              className="w-4 h-4 text-primary rounded border-gray-300"
              checked={formData.isActive} onChange={e => setFormData({...formData, isActive: e.target.checked})}
            />
            <span className="text-sm font-medium text-gray-700">منتج نشط (يظهر للعملاء)</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input 
              type="checkbox" 
              className="w-4 h-4 text-primary rounded border-gray-300"
              checked={formData.isFeatured} onChange={e => setFormData({...formData, isFeatured: e.target.checked})}
            />
            <span className="text-sm font-medium text-gray-700">منتج مميز (يظهر في الرئيسية)</span>
          </label>
        </div>
      </div>

      <div className="mt-8 flex justify-end gap-4 border-t pt-6">
        <button 
          type="button" 
          onClick={() => router.back()}
          className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
        >
          إلغاء
        </button>
        <button 
          type="submit" 
          disabled={loading}
          className="px-6 py-2 bg-primary text-white font-bold rounded-md hover:bg-opacity-90 disabled:opacity-50 flex items-center gap-2"
        >
          {loading ? "جاري الحفظ..." : "حفظ المنتج"}
        </button>
      </div>
    </form>
  );
}
