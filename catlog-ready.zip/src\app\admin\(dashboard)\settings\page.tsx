import { prisma } from "@/lib/prisma";
import { SettingsForm } from "./SettingsForm";

export default async function SettingsPage() {
  const dbSettings = await prisma.setting.findMany();
  
  // Convert array to key-value object
  const settings = dbSettings.reduce((acc, curr) => {
    acc[curr.key] = curr.value;
    return acc;
  }, {} as Record<string, string>);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">إعدادات النظام</h1>
      <SettingsForm settings={settings} />
    </div>
  );
}
