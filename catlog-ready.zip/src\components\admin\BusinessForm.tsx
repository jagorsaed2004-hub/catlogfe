"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ImageUpload } from "./ImageUpload";

export function BusinessForm({ initialData = {} }: { initialData?: any }) {
  const router = useRouter();
  const [formData, setFormData] = useState({
    name: initialData.name || "",
    slug: initialData.slug || "",
    description: initialData.description || "",
    imageUrl: initialData.imageUrl || "",
    sortOrder: initialData.sortOrder || 0,
    isActive: initialData.isActive !== false,
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const url = initialData.id ? `/api/admin/business/${initialData.id}` : '/api/admin/business';
      const method = initialData.id ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (res.ok) {
        router.push("/admin/business");
        router.refresh();
      } else {
        alert("حدث خطأ أثناء الحفظ");
      }
    } catch (error) {
      alert("حدث خطأ في الاتصال");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <div className="mb-8">
        <label className="block text-sm font-medium text-gray-700 mb-3">صورة المحل / النشاط</label>
        <ImageUpload 
          value={formData.imageUrl} 
          onChange={(url) => setFormData({...formData, imageUrl: url})} 
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">اسم النشاط (عربي) *</label>
          <input 
            type="text" required 
            className="w-full border border-gray-300 rounded-md px-3 py-2"
            value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">الرابط الإنجليزي (Slug) *</label>
          <input 
            type="text" required dir="ltr"
            className="w-full border border-gray-300 rounded-md px-3 py-2 text-left"
            value={formData.slug} onChange={e => setFormData({...formData, slug: e.target.value})}
          />
        </div>

        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">الوصف</label>
          <textarea 
            className="w-full border border-gray-300 rounded-md px-3 py-2" rows={3}
            value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})}
          ></textarea>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">الترتيب</label>
          <input 
            type="number" required 
            className="w-full border border-gray-300 rounded-md px-3 py-2"
            value={formData.sortOrder} onChange={e => setFormData({...formData, sortOrder: parseInt(e.target.value) || 0})}
          />
        </div>

        <div className="flex items-center mt-6">
          <label className="flex items-center gap-2 cursor-pointer">
            <input 
              type="checkbox" 
              className="w-4 h-4 text-primary rounded border-gray-300"
              checked={formData.isActive} onChange={e => setFormData({...formData, isActive: e.target.checked})}
            />
            <span className="text-sm font-medium text-gray-700">نشط (يظهر للعملاء)</span>
          </label>
        </div>
      </div>

      <div className="mt-8 flex justify-end gap-4 border-t pt-6">
        <button 
          type="button" 
          onClick={() => router.back()}
          className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
        >
          إلغاء
        </button>
        <button 
          type="submit" 
          disabled={loading}
          className="px-6 py-2 bg-primary text-white font-bold rounded-md hover:bg-opacity-90 disabled:opacity-50"
        >
          {loading ? "جاري الحفظ..." : "حفظ النشاط"}
        </button>
      </div>
    </form>
  );
}
