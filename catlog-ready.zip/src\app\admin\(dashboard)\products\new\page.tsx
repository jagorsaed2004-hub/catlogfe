import { ProductForm } from "@/components/admin/ProductForm";
import { prisma } from "@/lib/prisma";

export default async function NewProductPage() {
  const companies = await prisma.company.findMany({
    orderBy: { name: 'asc' }
  });
  
  const categories = await prisma.globalCategory.findMany({
    orderBy: { name: 'asc' }
  });

  const businessTypes = await prisma.businessType.findMany({
    orderBy: { name: 'asc' }
  });

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">إضافة منتج جديد</h1>
      <ProductForm companies={companies} categories={categories} businessTypes={businessTypes} />
    </div>
  );
}
