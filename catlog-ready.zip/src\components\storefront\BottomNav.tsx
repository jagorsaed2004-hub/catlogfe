"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Grid, Building2, Search, ShoppingCart, ClipboardList } from "lucide-react";
import { useCartStore } from "@/store/cartStore";
import { useEffect, useState } from "react";

export function BottomNav() {
  const pathname = usePathname();
  const getTotalItems = useCartStore((state) => state.getTotalItems);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const navItems = [
    { name: "الرئيسية", href: "/", icon: Home },
    { name: "الأقسام", href: "/categories", icon: Grid },
    { name: "الشركات", href: "/companies", icon: Building2 },
    { name: "طلباتي", href: "/my-orders", icon: ClipboardList },
    { name: "السلة", href: "/cart", icon: ShoppingCart, badge: true },
  ];

  return (
    <nav className="fixed bottom-0 w-full bg-white border-t border-gray-200 lg:hidden z-50">
      <div className="flex justify-around items-center h-16 px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;
          
          return (
            <Link 
              key={item.name} 
              href={item.href}
              className={`flex flex-col items-center justify-center w-full h-full space-y-1 relative ${isActive ? 'text-primary' : 'text-gray-500'}`}
            >
              <div className="relative">
                <Icon className={`w-6 h-6 ${isActive ? 'fill-primary/20' : ''}`} />
                {item.badge && mounted && getTotalItems() > 0 ? (
                  <span className="absolute -top-1 -right-2 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                    {getTotalItems()}
                  </span>
                ) : null}
              </div>
              <span className={`text-[10px] font-medium ${isActive ? 'font-bold' : ''}`}>
                {item.name}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
