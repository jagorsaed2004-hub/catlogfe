const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');

const prisma = new PrismaClient();

async function main() {
  // إنشاء حساب المدير
  const passwordHash = await bcrypt.hash('admin123', 10);
  
  const admin = await prisma.adminUser.upsert({
    where: { username: 'admin' },
    update: {},
    create: {
      username: 'admin',
      passwordHash: passwordHash,
      mustChangePassword: true,
    },
  });
  console.log('✅ تم إنشاء حساب المدير:', admin.username);

  // إعدادات المتجر
  const settings = [
    { key: 'storeName', value: 'مستلزمات التعبئة والتغليف' },
    { key: 'storePhone', value: '01000000000' },
    { key: 'whatsappNumber', value: '201000000000' },
    { key: 'currency', value: 'ج.م' },
  ];

  for (const s of settings) {
    await prisma.setting.upsert({
      where: { key: s.key },
      update: { value: s.value },
      create: { key: s.key, value: s.value },
    });
  }
  console.log('✅ تم إضافة إعدادات المتجر');

  console.log('\n🎉 تم تجهيز قاعدة البيانات بنجاح!');
  console.log('📌 بيانات الدخول: admin / admin123');
}

main()
  .catch((e) => {
    console.error('❌ خطأ:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
