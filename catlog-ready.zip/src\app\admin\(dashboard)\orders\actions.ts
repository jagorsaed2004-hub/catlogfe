"use server";

import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";

export async function updateOrderStatus(orderId: number, status: string) {
  await prisma.order.update({
    where: { id: orderId },
    data: { status }
  });

  revalidatePath('/admin/orders');
  revalidatePath('/my-orders'); // In case the user views it
}
