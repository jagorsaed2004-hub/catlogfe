import { Header } from "@/components/storefront/Header";
import { BottomNav } from "@/components/storefront/BottomNav";
import { WhatsAppFAB } from "@/components/storefront/WhatsAppFAB";
import { prisma } from "@/lib/prisma";
import { unstable_cache } from "next/cache";

const getSettings = unstable_cache(
  async () => {
    return await prisma.setting.findMany();
  },
  ['global-settings'],
  { revalidate: 3600 } // cache for 1 hour
);

export default async function StorefrontLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const settings = await getSettings();
  const whatsappSetting = settings.find(s => s.key === 'DEFAULT_WHATSAPP_NUMBER');
  const whatsappNumber = whatsappSetting?.value || "966500000000";

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 pb-16 lg:pb-0">
      <Header />
      <main className="flex-1 w-full max-w-7xl mx-auto pb-8">
        {children}
      </main>
      <WhatsAppFAB phoneNumber={whatsappNumber} />
      <BottomNav />
    </div>
  );
}
