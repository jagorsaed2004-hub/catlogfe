import { CategoryForm } from "@/components/admin/CategoryForm";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default async function EditCategoryPage({ params }: { params: { id: string } }) {
  const category = await prisma.globalCategory.findUnique({
    where: { id: parseInt(params.id) }
  });

  if (!category) {
    return <div className="p-8 text-center">القسم غير موجود</div>;
  }

  return (
    <div>
      <div className="flex items-center mb-6">
        <Link href="/admin/categories" className="p-2 -ml-2 text-gray-600 hover:text-gray-900 bg-gray-50 rounded-full ml-4">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold">تعديل القسم: {category.name}</h1>
      </div>
      <CategoryForm initialData={category} />
    </div>
  );
}
