import { prisma } from "@/lib/prisma";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import Link from "next/link";
import { Eye } from "lucide-react";

import { OrderActions } from "./OrderActions";

export default async function OrdersPage() {
  const orders = await prisma.order.findMany({
    orderBy: { createdAt: 'desc' },
    include: {
      items: true
    }
  });

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">الطلبات</h1>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200 text-right">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">رقم الطلب</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">رقم الجوال</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">عدد المنتجات</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">الإجمالي</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">التاريخ</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">الحالة</th>
              <th className="px-6 py-3 text-sm font-medium text-gray-500">تفاصيل</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {orders.map((order) => (
              <tr key={order.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">
                  {order.orderNumber}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dir-ltr text-right">
                  {order.customerPhone}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {order.items.length} منتج
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-primary">
                  {order.finalAmount ?? order.totalAmount} ج.م
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {format(new Date(order.createdAt), 'dd MMMM yyyy - hh:mm a', { locale: ar })}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <OrderActions orderId={order.id} currentStatus={order.status} />
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <Link href={`/admin/orders/${order.id}`} className="text-gray-400 hover:text-primary flex items-center gap-1 bg-gray-100 px-2 py-1 rounded">
                    فاتورة
                  </Link>
                </td>
              </tr>
            ))}
            {orders.length === 0 && (
              <tr>
                <td colSpan={7} className="px-6 py-8 text-center text-sm text-gray-500">
                  لا توجد طلبات حتى الآن
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
