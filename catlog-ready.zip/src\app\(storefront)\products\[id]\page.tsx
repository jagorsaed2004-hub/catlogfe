import { prisma } from "@/lib/prisma";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Share2, Heart, Box, Check } from "lucide-react";
import { AddToCartButton } from "./AddToCartButton";
import type { Metadata } from "next";

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  const product = await prisma.product.findUnique({
    where: { id: parseInt(params.id) },
    include: { company: true }
  });
  if (!product) return { title: "منتج غير موجود" };
  
  return {
    title: `${product.name} | ${product.company.name}`,
    description: product.description || `اشتري ${product.name} من ${product.company.name} بأفضل الأسعار. متوفر بسعر الكرتونة والقطعة.`,
    openGraph: {
      images: product.imageUrl ? [product.imageUrl] : [],
    }
  };
}

export default async function ProductDetailsPage({ params }: { params: { id: string } }) {
  const product = await prisma.product.findUnique({
    where: { id: parseInt(params.id) },
    include: {
      company: true,
      globalCategory: true
    }
  });

  if (!product) {
    return <div className="p-8 text-center text-xl">المنتج غير موجود</div>;
  }

  // Fetch related products (same category or company, excluding current)
  const relatedProducts = await prisma.product.findMany({
    where: {
      id: { not: product.id },
      isActive: true,
      OR: [
        { globalCategoryId: product.globalCategoryId },
        { companyId: product.companyId }
      ]
    },
    take: 4,
    orderBy: { createdAt: 'desc' }
  });

  return (
    <div className="p-4 mb-20 lg:mb-0 bg-white min-h-screen">
      {/* Top Nav */}
      <div className="flex items-center justify-between mb-4">
        <Link href="/" className="p-2 -ml-2 text-gray-600 hover:text-gray-900 bg-gray-50 rounded-full">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <div className="flex gap-2">
          <button className="p-2 text-gray-600 hover:text-red-500 bg-gray-50 rounded-full">
            <Heart className="w-5 h-5" />
          </button>
          <button className="p-2 text-gray-600 hover:text-primary bg-gray-50 rounded-full">
            <Share2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Image */}
      <div className="bg-[#F8F9FA] rounded-2xl p-8 mb-6 relative aspect-square flex items-center justify-center">
        {product.imageUrl ? (
          <Image src={product.imageUrl} alt={product.name} fill className="object-contain" />
        ) : (
          <Box className="w-24 h-24 text-gray-300" />
        )}
      </div>

      {/* Details */}
      <div className="mb-6">
        <div className="flex justify-between items-start mb-2">
          <h1 className="text-xl font-bold text-gray-900">{product.name}</h1>
          <div className="bg-gray-100 px-3 py-1 rounded text-xs font-bold text-gray-700">
            {product.company.name}
          </div>
        </div>
        <p className="text-sm text-gray-500 mb-4">{product.globalCategory?.name} {product.code && `| كود: ${product.code}`}</p>
        
        {/* Pricing */}
        <div className="flex gap-4 mb-6">
          <div className="flex-1 bg-gray-50 border border-gray-200 rounded-xl p-4 text-center">
            <p className="text-xs text-gray-500 mb-1">سعر الكرتونة</p>
            <p className="text-xl font-bold text-primary">{product.cartonPrice} <span className="text-sm font-normal">ج.م</span></p>
          </div>
          <div className="flex-1 bg-gray-50 border border-gray-200 rounded-xl p-4 text-center">
            <p className="text-xs text-gray-500 mb-1">سعر القطعة</p>
            <p className="text-xl font-bold text-primary">{product.piecePrice} <span className="text-sm font-normal">ج.م</span></p>
          </div>
        </div>

        {/* Specs */}
        <div className="space-y-3 mb-8">
          <div className="flex items-center text-sm">
            <Check className="w-4 h-4 text-green-500 ml-2" />
            <span className="text-gray-600 w-24">العبوة:</span>
            <span className="font-semibold">{product.piecesPerCarton} قطعة / كرتونة</span>
          </div>
          {product.size && (
            <div className="flex items-center text-sm">
              <Check className="w-4 h-4 text-green-500 ml-2" />
              <span className="text-gray-600 w-24">المقاس:</span>
              <span className="font-semibold text-left" dir="ltr">{product.size}</span>
            </div>
          )}
          {product.capacity && (
            <div className="flex items-center text-sm">
              <Check className="w-4 h-4 text-green-500 ml-2" />
              <span className="text-gray-600 w-24">السعة:</span>
              <span className="font-semibold text-left" dir="ltr">{product.capacity}</span>
            </div>
          )}
        </div>

        {product.description && (
          <div className="mb-8">
            <h3 className="font-bold text-gray-900 mb-2">وصف المنتج</h3>
            <p className="text-sm text-gray-600 leading-relaxed">{product.description}</p>
          </div>
        )}
      </div>

      <AddToCartButton product={product as any} />

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="mt-12 pt-8 border-t border-gray-100">
          <h3 className="font-bold text-xl text-gray-900 mb-6">منتجات قد تحتاجها أيضاً</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {relatedProducts.map(rp => (
              <Link href={`/products/${rp.id}`} key={rp.id} className="bg-white border border-gray-100 rounded-xl p-3 hover:shadow-md transition block">
                <div className="relative aspect-square bg-gray-50 rounded-lg mb-3">
                  {rp.imageUrl ? (
                    <Image src={rp.imageUrl} alt={rp.name} fill className="object-contain p-2" />
                  ) : (
                    <Box className="absolute inset-0 m-auto text-gray-300 w-8 h-8" />
                  )}
                </div>
                <h4 className="text-sm font-bold text-gray-900 truncate">{rp.name}</h4>
                <p className="text-primary font-bold text-sm mt-1">{rp.cartonPrice} ج.م</p>
              </Link>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
