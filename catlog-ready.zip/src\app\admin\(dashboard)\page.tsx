import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export default async function AdminDashboard() {
  const productsCount = await prisma.product.count();
  const companiesCount = await prisma.company.count();
  const ordersCount = await prisma.order.count();
  
  const orders = await prisma.order.findMany({
    select: { finalAmount: true, totalAmount: true }
  });
  
  const totalSales = orders.reduce((acc, order) => acc + (order.finalAmount ?? order.totalAmount), 0);

  const recentOrders = await prisma.order.findMany({
    take: 5,
    orderBy: { createdAt: 'desc' },
    include: { items: true }
  });

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">إحصائيات النظام</h1>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 border-r-4 border-r-green-500">
          <h2 className="text-gray-500 text-sm font-bold">إجمالي المبيعات</h2>
          <p className="text-3xl font-bold mt-2 text-green-600">{totalSales} <span className="text-sm">ج.م</span></p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 border-r-4 border-r-blue-500">
          <h2 className="text-gray-500 text-sm font-bold">إجمالي الطلبات</h2>
          <p className="text-3xl font-bold mt-2">{ordersCount}</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 border-r-4 border-r-primary">
          <h2 className="text-gray-500 text-sm font-bold">إجمالي المنتجات</h2>
          <p className="text-3xl font-bold mt-2">{productsCount}</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 border-r-4 border-r-yellow-500">
          <h2 className="text-gray-500 text-sm font-bold">الشركات</h2>
          <p className="text-3xl font-bold mt-2">{companiesCount}</p>
        </div>
      </div>

      <h2 className="text-xl font-bold mb-4">أحدث الطلبات</h2>
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <table className="min-w-full text-right">
          <thead className="bg-gray-50 text-gray-500 text-sm">
            <tr>
              <th className="p-4 font-medium">رقم الطلب</th>
              <th className="p-4 font-medium">العميل</th>
              <th className="p-4 font-medium">المبلغ</th>
              <th className="p-4 font-medium">التاريخ</th>
              <th className="p-4 font-medium">إجراء</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 text-sm">
            {recentOrders.map(order => (
              <tr key={order.id} className="hover:bg-gray-50">
                <td className="p-4 font-bold">{order.orderNumber}</td>
                <td className="p-4 dir-ltr text-right">{order.customerPhone}</td>
                <td className="p-4 font-bold text-primary">{order.finalAmount ?? order.totalAmount} ج.م</td>
                <td className="p-4 text-gray-500">{format(new Date(order.createdAt), 'dd MMMM yyyy', { locale: ar })}</td>
                <td className="p-4">
                  <Link href={`/admin/orders/${order.id}`} className="text-blue-500 hover:underline">عرض الفاتورة</Link>
                </td>
              </tr>
            ))}
            {recentOrders.length === 0 && (
              <tr><td colSpan={5} className="p-4 text-center text-gray-500">لا توجد طلبات بعد</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
