"use client";

import { useCartStore } from "@/store/cartStore";
import Image from "next/image";
import Link from "next/link";
import { Trash2, Plus, Minus, ArrowRight } from "lucide-react";
import { useState, useEffect } from "react";

export default function CartPage() {
  const { items, removeItem, updateQuantity, getTotalPrice, clearCart } = useCartStore();
  const [mounted, setMounted] = useState(false);
  const [phone, setPhone] = useState("");
  const [storePhone, setStorePhone] = useState("966500000000"); // default

  useEffect(() => {
    setMounted(true);
    // Load saved phone from previous orders
    const savedPhone = localStorage.getItem('customerPhone');
    if (savedPhone) setPhone(savedPhone);
    // Load WhatsApp number from settings
    fetch('/api/settings').then(res => res.json()).then(data => {
      if (data.DEFAULT_WHATSAPP_NUMBER) setStorePhone(data.DEFAULT_WHATSAPP_NUMBER);
    }).catch(() => {});
  }, []);

  if (!mounted) return null; // Avoid hydration mismatch

  const handleCheckout = async () => {
    if (!phone) {
      alert("الرجاء إدخال رقم الجوال");
      return;
    }

    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone,
          items,
          totalAmount: getTotalPrice()
        })
      });
      
      if (!res.ok) throw new Error();
      
      // Save phone to local storage for future retrieval
      localStorage.setItem('customerPhone', phone);

      let message = `*طلب جديد من الكتالوج*%0A`;
      message += `رقم الجوال: ${phone}%0A%0A`;
      message += `*المنتجات:*%0A`;
      
      items.forEach((item, index) => {
        message += `${index + 1}. ${item.name} (${item.companyName})%0A`;
        message += `   الكمية: ${item.quantity} ${item.unit === 'carton' ? 'كرتونة' : 'قطعة'}%0A`;
        message += `   السعر: ${item.unitPrice * item.quantity} ج.م%0A`;
        if (item.code) message += `   كود: ${item.code}%0A`;
        message += `%0A`;
      });

      message += `*الإجمالي: ${getTotalPrice()} ج.م*`;

      const whatsappUrl = `https://wa.me/${storePhone}?text=${message}`;
      window.open(whatsappUrl, '_blank');
      
      // Clear cart after successful checkout
      clearCart(); 
      
    } catch (e) {
      alert("حدث خطأ أثناء حفظ الطلب، يرجى المحاولة مرة أخرى.");
    }
  };

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] px-4">
        <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
          <Trash2 className="w-10 h-10 text-gray-400" />
        </div>
        <h2 className="text-xl font-bold mb-2">سلة المشتريات فارغة</h2>
        <p className="text-gray-500 mb-6 text-center">لم تقم بإضافة أي منتجات إلى سلة المشتريات حتى الآن.</p>
        <Link href="/" className="bg-primary text-white px-6 py-3 rounded-full font-bold hover:bg-opacity-90 transition-all">
          تصفح المنتجات
        </Link>
      </div>
    );
  }

  return (
    <div className="p-4 mb-20 lg:mb-0">
      <div className="flex items-center mb-6">
        <Link href="/" className="p-2 -ml-2 text-gray-600 hover:text-gray-900">
          <ArrowRight className="w-6 h-6" />
        </Link>
        <h1 className="text-2xl font-bold mr-2">سلة المشتريات</h1>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        <div className="flex-1">
          {items.map((item) => (
            <div key={item.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 mb-4 flex gap-4">
              <div className="w-20 h-20 bg-gray-50 rounded-lg relative flex-shrink-0 flex items-center justify-center">
                 {item.imageUrl ? (
                   <Image src={item.imageUrl} alt={item.name} fill className="object-contain p-2" />
                 ) : (
                   <span className="text-[10px] text-gray-400">صورة</span>
                 )}
              </div>
              
              <div className="flex-1 flex flex-col">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-gray-900 text-sm leading-tight mb-1">{item.name}</h3>
                    <p className="text-[10px] text-gray-500">{item.companyName} {item.code && `| كود: ${item.code}`}</p>
                    <p className="text-xs font-bold text-primary mt-1">
                      {item.unitPrice} ج.م <span className="text-gray-400 text-[10px] font-normal">/ {item.unit === 'carton' ? 'كرتونة' : 'قطعة'}</span>
                    </p>
                  </div>
                  <button 
                    onClick={() => removeItem(item.id)}
                    className="p-1 text-red-400 hover:text-red-600 hover:bg-red-50 rounded"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="mt-auto flex justify-between items-end">
                  <p className="font-bold text-sm text-gray-900">
                    {item.unitPrice * item.quantity} ج.م
                  </p>
                  
                  <div className="flex items-center bg-gray-50 rounded-lg border border-gray-200">
                    <button 
                      onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                      className="p-1.5 text-gray-600 hover:text-primary"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-8 text-center text-sm font-semibold">{item.quantity}</span>
                    <button 
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="p-1.5 text-gray-600 hover:text-primary"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="lg:w-1/3">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 sticky top-20">
            <h2 className="font-bold text-lg mb-4">ملخص الطلب</h2>
            
            <div className="space-y-3 mb-6 text-sm">
              <div className="flex justify-between text-gray-600">
                <span>المنتجات ({items.length})</span>
                <span>{getTotalPrice()} ج.م</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>التوصيل</span>
                <span className="text-xs">يحدد لاحقاً</span>
              </div>
              <div className="border-t border-gray-100 pt-3 flex justify-between font-bold text-lg text-gray-900">
                <span>الإجمالي</span>
                <span>{getTotalPrice()} ج.م</span>
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">رقم الجوال لتأكيد الطلب</label>
              <input 
                type="tel" 
                placeholder="05XXXXXXXX"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-4 py-3 text-left dir-ltr focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            <button 
              onClick={handleCheckout}
              className="w-full bg-whatsapp text-white py-3 rounded-xl font-bold text-lg flex items-center justify-center hover:scale-[1.02] transition-transform"
            >
              إرسال الطلب عبر واتساب
            </button>
            <p className="text-center text-xs text-gray-500 mt-3">سيتم تحويلك إلى واتساب لإرسال تفاصيل الطلب</p>
          </div>
        </div>
      </div>
    </div>
  );
}
