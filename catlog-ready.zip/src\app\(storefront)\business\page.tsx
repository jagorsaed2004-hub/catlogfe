import { prisma } from "@/lib/prisma";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default async function AllBusinessTypesPage() {
  const types = await prisma.businessType.findMany({
    orderBy: { sortOrder: 'asc' }
  });

  return (
    <div className="p-4 mb-20 lg:mb-0 min-h-screen bg-gray-50">
      <div className="flex items-center mb-6">
        <Link href="/" className="p-2 -ml-2 text-gray-600 hover:text-gray-900 bg-white rounded-full ml-4 shadow-sm">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold text-gray-900">تسوق حسب نشاطك</h1>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {types.map((type) => (
          <Link 
            key={type.id} 
            href={`/business/${type.slug}`}
            className="bg-white rounded-2xl overflow-hidden flex flex-col shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
          >
            <div className="h-[120px] bg-[#E8EDF2] relative w-full p-4">
               {type.imageUrl ? (
                 <Image src={type.imageUrl} alt={type.name} fill className="object-cover" />
               ) : (
                 <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">صورة معبرة</div>
               )}
            </div>
            <div className="p-4 text-center">
              <h3 className="font-bold text-gray-900 text-base">{type.name}</h3>
              <p className="text-xs text-gray-500 mt-1">{type.description}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
