﻿"use client";

import { useState } from "react";
import * as XLSX from "xlsx";

export default function PriceUpdaterPage() {
  const [file, setFile] = useState<File | null>(null);
  const [priceType, setPriceType] = useState<"carton" | "piece">("carton");
  const [preview, setPreview] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (!uploadedFile) return;
    setFile(uploadedFile);

    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: "binary" });
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];
      const data = XLSX.utils.sheet_to_json(ws, { header: 1 });
      
      // Expected: Col 0 = Code, Col 1 = New Price
      const parsedData = data.slice(1).map((row: any) => ({
        code: row[0]?.toString(),
        newPrice: parseFloat(row[1])
      })).filter(r => r.code && !isNaN(r.newPrice));
      
      setPreview(parsedData);
    };
    reader.readAsBinaryString(uploadedFile);
  };

  const handleUpdate = async () => {
    if (preview.length === 0) return;
    setLoading(true);
    // TODO: Send to API
    setTimeout(() => {
      setLoading(false);
      alert("تم تحديث الأسعار بنجاح!");
      setPreview([]);
      setFile(null);
    }, 1500);
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">تحديث الأسعار بالجملة (Excel)</h1>
      
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-6">
        <div className="mb-6">
          <p className="text-sm text-gray-600 mb-2">قم برفع ملف Excel يحتوي على عمودين فقط:</p>
          <ul className="list-disc list-inside text-sm text-gray-600 mb-4">
            <li>العمود الأول: <strong>كود المنتج</strong></li>
            <li>العمود الثاني: <strong>السعر الجديد</strong></li>
          </ul>
        </div>

        <div className="flex gap-6 items-end">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">نوع السعر المُراد تحديثه</label>
            <select 
              className="w-full border border-gray-300 rounded-md px-3 py-2"
              value={priceType}
              onChange={(e) => setPriceType(e.target.value as "carton" | "piece")}
            >
              <option value="carton">سعر الكرتونة</option>
              <option value="piece">سعر القطعة</option>
            </select>
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">ملف Excel (.xlsx)</label>
            <input 
              type="file" accept=".xlsx, .xls"
              className="w-full border border-gray-300 rounded-md px-3 py-1.5"
              onChange={handleFileUpload}
            />
          </div>
        </div>
      </div>

      {preview.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="p-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
            <h2 className="font-semibold text-gray-700">معاينة البيانات ({preview.length} منتج)</h2>
            <button 
              onClick={handleUpdate}
              disabled={loading}
              className="bg-primary text-white px-4 py-2 rounded-md hover:bg-opacity-90 disabled:opacity-50"
            >
              {loading ? "جاري التحديث..." : "تأكيد تحديث الأسعار"}
            </button>
          </div>
          <table className="min-w-full divide-y divide-gray-200 text-right">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-sm font-medium text-gray-500">كود المنتج</th>
                <th className="px-6 py-3 text-sm font-medium text-gray-500">السعر الجديد</th>
                <th className="px-6 py-3 text-sm font-medium text-gray-500">حالة المطابقة</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {preview.slice(0, 10).map((item, idx) => (
                <tr key={idx}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.code}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.newPrice} ج.م</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <span className="text-yellow-600 bg-yellow-100 px-2 py-1 rounded text-xs">قيد الفحص...</span>
                  </td>
                </tr>
              ))}
              {preview.length > 10 && (
                <tr>
                  <td colSpan={3} className="px-6 py-4 text-center text-sm text-gray-500 bg-gray-50">
                    ... و {preview.length - 10} منتج آخر
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
