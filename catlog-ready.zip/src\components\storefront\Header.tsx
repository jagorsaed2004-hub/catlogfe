"use client";

import Link from "next/link";
import { Menu, ShoppingCart, Box, Search } from "lucide-react";
import { useCartStore } from "@/store/cartStore";
import { useEffect, useState } from "react";

export function Header() {
  const getTotalItems = useCartStore((state) => state.getTotalItems);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  return (
    <header className="sticky top-0 z-50 bg-white w-full border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        
        {/* Right side (Menu) in RTL */}
        <div className="flex items-center gap-1">
          <button className="p-2 text-gray-800 hover:bg-gray-50 rounded-full">
            <Menu className="w-6 h-6" />
          </button>
          <Link href="/search" className="p-2 text-gray-800 hover:bg-gray-50 rounded-full">
            <Search className="w-5 h-5" />
          </Link>
        </div>

        {/* Center (Logo) */}
        <Link href="/" className="flex flex-col items-center justify-center">
          <div className="flex items-center gap-2">
            <Box className="w-6 h-6 text-primary" strokeWidth={2.5} />
            <h1 className="text-primary font-bold text-lg leading-tight">مستلزمات التعبئة والتغليف</h1>
          </div>
          <span className="text-gray-500 text-[10px]">جودة تناسب جميع احتياجاتك</span>
        </Link>

        {/* Left side (Cart) in RTL */}
        <Link href="/cart" className="p-2 text-gray-800 hover:bg-gray-50 rounded-full relative">
          <ShoppingCart className="w-6 h-6" />
          {mounted && getTotalItems() > 0 && (
            <span className="absolute top-1 right-1 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
              {getTotalItems()}
            </span>
          )}
        </Link>
        
      </div>
    </header>
  );
}
