"use client";

import { useRouter, useSearchParams } from "next/navigation";

export function ProductFilter({ 
  companies, 
  categories 
}: { 
  companies: {id: number, name: string}[],
  categories: {id: number, name: string}[]
}) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const handleFilter = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value) params.set(key, value);
    else params.delete(key);
    router.push(`/products?${params.toString()}`);
  };

  return (
    <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 mb-6 flex flex-wrap gap-4 items-center">
      <div className="flex items-center gap-2">
        <span className="text-sm font-bold text-gray-700">تصفية حسب:</span>
      </div>
      
      <select 
        className="bg-gray-50 border border-gray-200 text-gray-800 text-sm rounded-lg px-3 py-2 outline-none focus:border-primary"
        value={searchParams.get('companyId') || ""}
        onChange={(e) => handleFilter('companyId', e.target.value)}
      >
        <option value="">كل الشركات</option>
        {companies.map(c => (
          <option key={c.id} value={c.id.toString()}>{c.name}</option>
        ))}
      </select>

      <select 
        className="bg-gray-50 border border-gray-200 text-gray-800 text-sm rounded-lg px-3 py-2 outline-none focus:border-primary"
        value={searchParams.get('categoryId') || ""}
        onChange={(e) => handleFilter('categoryId', e.target.value)}
      >
        <option value="">كل الأقسام</option>
        {categories.map(c => (
          <option key={c.id} value={c.id.toString()}>{c.name}</option>
        ))}
      </select>

      <div className="flex-1"></div>

      {/* Clear Filters */}
      {(searchParams.get('companyId') || searchParams.get('categoryId')) && (
        <button 
          onClick={() => router.push('/products')}
          className="text-xs text-red-500 font-medium hover:underline"
        >
          مسح الفلاتر
        </button>
      )}
    </div>
  );
}
