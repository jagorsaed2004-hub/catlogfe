import { ProductForm } from "@/components/admin/ProductForm";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default async function EditProductPage({ params }: { params: { id: string } }) {
  const product = await prisma.product.findUnique({
    where: { id: parseInt(params.id) },
    include: { businessTypeProducts: true }
  });

  if (!product) {
    return <div className="p-8 text-center">المنتج غير موجود</div>;
  }

  const companies = await prisma.company.findMany({
    orderBy: { name: 'asc' }
  });
  
  const categories = await prisma.globalCategory.findMany({
    orderBy: { name: 'asc' }
  });

  const businessTypes = await prisma.businessType.findMany({
    orderBy: { name: 'asc' }
  });

  return (
    <div>
      <div className="flex items-center mb-6">
        <Link href="/admin/products" className="p-2 -ml-2 text-gray-600 hover:text-gray-900 bg-gray-50 rounded-full ml-4">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold">تعديل المنتج: {product.name}</h1>
      </div>
      
      <ProductForm 
        initialData={product} 
        companies={companies} 
        categories={categories} 
        businessTypes={businessTypes}
      />
    </div>
  );
}
