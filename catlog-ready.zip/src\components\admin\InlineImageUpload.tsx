"use client";

import { useState } from "react";
import Image from "next/image";
import { Camera, Loader2 } from "lucide-react";

export function InlineImageUpload({ 
  currentUrl, 
  entityType, 
  entityId,
  fieldName = "imageUrl"
}: { 
  currentUrl?: string | null, 
  entityType: "products" | "companies" | "categories" | "business",
  entityId: number,
  fieldName?: string
}) {
  const [imageUrl, setImageUrl] = useState(currentUrl || "");
  const [loading, setLoading] = useState(false);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      // 1. Upload file
      const formData = new FormData();
      formData.append("file", file);
      const uploadRes = await fetch("/api/upload", { method: "POST", body: formData });
      const uploadData = await uploadRes.json();
      
      if (!uploadData.url) throw new Error("Upload failed");

      // 2. Update entity in DB
      const updateRes = await fetch(`/api/admin/${entityType}/${entityId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ [fieldName]: uploadData.url })
      });

      if (updateRes.ok) {
        setImageUrl(uploadData.url);
      } else {
        alert("تم رفع الصورة لكن فشل حفظها");
      }
    } catch (error) {
      alert("حدث خطأ أثناء رفع الصورة");
    } finally {
      setLoading(false);
    }
  };

  return (
    <label className="flex-shrink-0 h-12 w-12 relative bg-gray-100 rounded-lg overflow-hidden cursor-pointer group border border-gray-200 hover:border-primary transition-colors">
      {loading ? (
        <div className="w-full h-full flex items-center justify-center">
          <Loader2 className="w-5 h-5 text-primary animate-spin" />
        </div>
      ) : imageUrl ? (
        <>
          <Image src={imageUrl} alt="img" fill className="object-contain p-1" />
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <Camera className="w-4 h-4 text-white" />
          </div>
        </>
      ) : (
        <div className="w-full h-full flex items-center justify-center text-gray-400 group-hover:text-primary transition-colors">
          <Camera className="w-5 h-5" />
        </div>
      )}
      <input type="file" className="hidden" accept="image/*" onChange={handleUpload} disabled={loading} />
    </label>
  );
}
