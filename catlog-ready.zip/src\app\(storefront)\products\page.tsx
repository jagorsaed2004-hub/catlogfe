import { prisma } from "@/lib/prisma";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Heart } from "lucide-react";
import { ProductFilter } from "@/components/storefront/ProductFilter";

export default async function AllProductsPage({
  searchParams,
}: {
  searchParams: { featured?: string, companyId?: string, categoryId?: string };
}) {
  const isFeatured = searchParams.featured === 'true';
  const companyId = searchParams.companyId ? parseInt(searchParams.companyId) : undefined;
  const categoryId = searchParams.categoryId ? parseInt(searchParams.categoryId) : undefined;

  const products = await prisma.product.findMany({
    where: { 
      isActive: true,
      ...(isFeatured ? { isFeatured: true } : {}),
      ...(companyId ? { companyId } : {}),
      ...(categoryId ? { globalCategoryId: categoryId } : {})
    },
    include: { company: true },
    orderBy: { createdAt: 'desc' }
  });

  const companies = await prisma.company.findMany({ where: { isActive: true }, select: { id: true, name: true } });
  const categories = await prisma.globalCategory.findMany({ where: { isActive: true }, select: { id: true, name: true } });

  return (
    <div className="p-4 mb-20 lg:mb-0 min-h-screen bg-gray-50">
      <div className="flex items-center mb-6">
        <Link href="/" className="p-2 -ml-2 text-gray-600 hover:text-gray-900 bg-white rounded-full ml-4 shadow-sm">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold text-gray-900">{isFeatured ? 'المنتجات المميزة' : 'جميع المنتجات'}</h1>
      </div>

      <ProductFilter companies={companies} categories={categories} />

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {products.map((product) => (
          <div key={product.id} className="bg-white rounded-xl border border-gray-100 flex flex-col overflow-hidden">
            <div className="absolute z-10 p-2">
              <button className="text-gray-400 hover:text-red-500"><Heart className="w-5 h-5" /></button>
            </div>
            <Link href={`/products/${product.id}`} className="h-[140px] bg-[#F8F9FA] relative p-4 flex items-center justify-center">
               {product.imageUrl ? (
                 <Image src={product.imageUrl} alt={product.name} fill className="object-contain p-4" />
               ) : (
                 <div className="text-gray-300 text-xs">صورة المنتج</div>
               )}
            </Link>
            <div className="p-3 flex flex-col flex-1">
              <Link href={`/products/${product.id}`}>
                <h3 className="font-semibold text-primary text-xs line-clamp-1 mb-1">{product.name}</h3>
                <p className="text-[10px] text-gray-500">{product.company?.name || 'عام'} {product.code && `| ${product.code}`}</p>
                <p className="font-bold text-gray-900 text-sm mt-1">{product.cartonPrice} ج.م</p>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
