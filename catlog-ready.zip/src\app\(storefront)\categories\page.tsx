import { prisma } from "@/lib/prisma";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default async function AllCategoriesPage() {
  const categories = await prisma.globalCategory.findMany({
    orderBy: { sortOrder: 'asc' }
  });

  return (
    <div className="p-4 mb-20 lg:mb-0 min-h-screen bg-gray-50">
      <div className="flex items-center mb-6">
        <Link href="/" className="p-2 -ml-2 text-gray-600 hover:text-gray-900 bg-white rounded-full ml-4 shadow-sm">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold text-gray-900">جميع الأقسام</h1>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {categories.map((cat) => (
          <Link 
            key={cat.id} 
            href={`/category/${cat.slug}`}
            className="bg-white rounded-2xl p-4 flex flex-col items-center shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
          >
            <div className="w-[100px] h-[100px] bg-[#EEF5FF] rounded-xl relative mb-3 p-2">
               {cat.imageUrl ? (
                 <Image src={cat.imageUrl} alt={cat.name} fill className="object-contain p-2" />
               ) : (
                 <div className="w-full h-full flex items-center justify-center text-gray-400 text-[10px]">صورة</div>
               )}
            </div>
            <span className="text-sm font-bold text-gray-900 text-center w-full truncate">
              {cat.name}
            </span>
          </Link>
        ))}
      </div>
    </div>
  );
}
