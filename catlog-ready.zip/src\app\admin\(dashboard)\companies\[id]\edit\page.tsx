import { CompanyForm } from "@/components/admin/CompanyForm";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default async function EditCompanyPage({ params }: { params: { id: string } }) {
  const company = await prisma.company.findUnique({
    where: { id: parseInt(params.id) }
  });

  if (!company) {
    return <div className="p-8 text-center">الشركة غير موجودة</div>;
  }

  return (
    <div>
      <div className="flex items-center mb-6">
        <Link href="/admin/companies" className="p-2 -ml-2 text-gray-600 hover:text-gray-900 bg-gray-50 rounded-full ml-4">
          <ArrowRight className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold">تعديل الشركة: {company.name}</h1>
      </div>
      <CompanyForm initialData={company} />
    </div>
  );
}
