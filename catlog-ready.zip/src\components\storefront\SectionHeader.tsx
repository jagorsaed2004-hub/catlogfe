import Link from "next/link";
import { ChevronLeft } from "lucide-react";

interface SectionHeaderProps {
  title: string;
  href?: string;
}

export function SectionHeader({ title, href }: SectionHeaderProps) {
  return (
    <div className="flex items-center justify-between mb-4 px-4 mt-8">
      <h2 className="text-xl font-bold text-gray-900">{title}</h2>
      {href && (
        <Link href={href} className="flex items-center text-primary text-sm font-medium hover:underline">
          عرض الكل
          <ChevronLeft className="w-4 h-4 mr-1" />
        </Link>
      )}
    </div>
  );
}
