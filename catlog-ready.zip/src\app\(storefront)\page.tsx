import { HeroBanner } from "@/components/storefront/HeroBanner";
import { BusinessTypeSection } from "@/components/storefront/BusinessTypeSection";
import { CompaniesSection } from "@/components/storefront/CompaniesSection";
import { CategoriesSection } from "@/components/storefront/CategoriesSection";
import { FeaturedProducts } from "@/components/storefront/FeaturedProducts";
import { prisma } from "@/lib/prisma";

export default async function HomePage() {
  const businessTypes = await prisma.businessType.findMany({
    orderBy: { sortOrder: 'asc' },
    take: 4
  });

  const companies = await prisma.company.findMany({
    where: { isActive: true },
    orderBy: { sortOrder: 'asc' },
    take: 5
  });

  const categories = await prisma.globalCategory.findMany({
    orderBy: { sortOrder: 'asc' },
    take: 6
  });

  const products = await prisma.product.findMany({
    where: { isFeatured: true, isActive: true },
    take: 4,
    include: { company: true }
  });

  return (
    <div className="flex flex-col gap-2">
      <HeroBanner />
      <BusinessTypeSection types={businessTypes} />
      <CompaniesSection companies={companies} />
      <CategoriesSection categories={categories} />
      <FeaturedProducts products={products} />
    </div>
  );
}
