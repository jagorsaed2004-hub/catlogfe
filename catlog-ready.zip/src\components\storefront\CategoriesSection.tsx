import { SectionHeader } from "./SectionHeader";
import Link from "next/link";
import Image from "next/image";

export function CategoriesSection({ categories }: { categories: any[] }) {
  return (
    <section>
      <SectionHeader title="الأقسام الرئيسية" href="/categories" />
      
      <div className="flex overflow-x-auto gap-4 px-4 pb-4 snap-x hide-scrollbar">
        {categories.map((cat) => (
          <Link 
            key={cat.id} 
            href={`/category/${cat.slug}`}
            className="flex-shrink-0 w-[100px] snap-start flex flex-col items-center"
          >
            <div className="w-[100px] h-[100px] bg-[#EEF5FF] rounded-2xl relative mb-2 p-2">
               {cat.imageUrl ? (
                 <Image src={cat.imageUrl} alt={cat.name} fill className="object-contain p-2" />
               ) : (
                 <div className="w-full h-full flex items-center justify-center text-gray-400 text-[10px]">صورة</div>
               )}
            </div>
            <span className="text-xs font-bold text-gray-900 text-center w-full truncate">
              {cat.name}
            </span>
          </Link>
        ))}
      </div>
    </section>
  );
}
