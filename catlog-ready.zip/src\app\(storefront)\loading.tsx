import { Loader2 } from "lucide-react";

export default function Loading() {
  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <div className="flex flex-col items-center text-primary">
        <Loader2 className="w-10 h-10 animate-spin mb-4" />
        <p className="font-bold text-gray-500">جاري التحميل...</p>
      </div>
    </div>
  );
}
