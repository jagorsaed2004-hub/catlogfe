import { SectionHeader } from "./SectionHeader";
import Link from "next/link";
import Image from "next/image";

export function BusinessTypeSection({ types }: { types: any[] }) {
  return (
    <section>
      <SectionHeader title="تسوق حسب نشاطك" href="/business" />
      
      <div className="flex overflow-x-auto gap-4 px-4 pb-4 snap-x hide-scrollbar">
        {types.map((type) => (
          <Link 
            key={type.id} 
            href={`/business/${type.slug}`}
            className="flex-shrink-0 w-[140px] snap-start bg-white rounded-2xl overflow-hidden flex flex-col"
          >
            <div className="h-[100px] bg-[#E8EDF2] relative rounded-t-2xl w-full">
               {type.imageUrl ? (
                 <Image src={type.imageUrl} alt={type.name} fill className="object-cover" />
               ) : (
                 <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">صورة</div>
               )}
            </div>
            <div className="p-3 text-center">
              <h3 className="font-bold text-gray-900 text-sm">{type.name}</h3>
              <p className="text-[10px] text-gray-500 mt-1 line-clamp-1">{type.description}</p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
